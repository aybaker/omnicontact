#!/usr/bin/python
# -*- coding: utf8 -*-

#/* Maxima cantidad de intentos que se permitiran para que el sms sea enviado */
MAX_INTENTOS = 2

#/* Periodo a respetar entre una alerta de email/sms y la proxima alerta a llegar (se mide en segundos) */
PERIODO_ALERTAS = 60 #segundos

#/* FLAG_CONTACTAR_EMAIL_ERROR: Indica si esta habilitada la contactacion por email ante errores (0:NO/1:SI) */
FLAG_CONTACTAR_EMAIL_ERROR = 1

#/* FLAG_CONTACTAR_SMS_ERROR: Indica si esta habilitada la contactacion por sms ante errores(0:NO/1:SI) */
FLAG_CONTACTAR_SMS_ERROR = 1

#/* CONTACTAR_EMAIL: email de contacto, se pueden colocar varios separados por un espacio */
CONTACTAR_EMAIL = 'doberti@gmail.com'

#/* CONTACTAR_CELU: Celular de contacto para el sms periodico que se envia cada cierta cantidad de envios (CONTACTAR_CANT) */
CONTACTAR_PERIODO_CELU = '0351152581376'

#/* CONTACTAR_CANT: Cantidad de sms enviados a partir del cual se debe enviar un sms al celular de contacto */
CONTACTAR_PERIODO_CANT = 20

#/* FAIL_CONTACTAR_CELU: Celular de contacto donde enviar mensajes ante posibles errores */
FAIL_CONTACTAR_CELU = '0351152581376'

#/* FAIL_CANT_SEND: Cuando se supere esta cantidad de sms fallidos se procede a enviar un sms al celular de contacto (FAIL_CONTACTAR_CELU) en el rango de 10 minutos y al email de contacto */
FAIL_CANT_SEND = 20

#/* DORMIR_TIME: Tiempo de descanso adicional, asociado a la cantidad de envios (DORMIR_CANT) */
DORMIR_TIME = 10

#/* DORMIR_CANT: Cantidad de envios que deben realizarse antes de hacer un descanso adicional (DORMIR_TIME) */
DORMIR_CANT = 100

#/* INTERVALO_ENVIOS: Cantidad de segundos entre cada sms enviado */
INTERVALO_ENVIOS = 40

#/* HR_INICIO: Hora en que inicia servicio */
HR_INICIO = -1

#/* HR_FIN: Hora en que inicia servicio */
HR_FIN = 25

#/* BUFER_SMS: Cantidad total de sms por cada Campania que se barrera por cada lectura a la base de datos */
BUFER_SMS = 30

