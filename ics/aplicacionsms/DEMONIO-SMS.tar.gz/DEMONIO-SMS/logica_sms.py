#!/usr/bin/python
# -*- coding: utf8 -*-

from settings import *
from hot_settings import *

import psycopg2

import socket
import string
import commands

import time
import os
import datetime
from time import gmtime, strftime

import math
import sys

import random

import threading

#el minimo intervalo posible es de 10 segundos
if INTERVALO_ENVIOS < 10:
	INTERVALO_ENVIOS = 10

class SMS:

	def __init__(self):
		self.conectado = 0
		self.listaModems = MODEMS
		self.listaPIDS = PIDS
		self.listaModemsOff = []
		self.listaPhoneID = {}
		self.indiceModem = 0
		self.contadorEnvios = 0
		self.connection = None
		self.cursor = None
		self.lastSMSout_resp = ''
		self.lastSMSout_celu = ''
		self.lastSMSout_codigo = ''
		self.lastSMSout_modem = ''
		self.h_alerta_enviada = int( time.time() )
		self.f_alerta_enviada = 0
		FECHA = time.strftime("%F %T")
		FECHA2 = time.strftime("%Y%m%d")
		HORA = str( time.strftime("%H:%M") )
		self.LoadPhoneID()
		self.ConectarDB()
		comando = "ls /bin/mailx | wc -l"
		flag_mailx_install = int(commands.getoutput(comando))
		print "flag_mailx_install:"+str(flag_mailx_install)
		if flag_mailx_install==0:
			print "El servicio mailx no se encuentra instalado..."
			print "procediendo con la instalacion de mailx..."
			comando = "yum -y install mailx"
			print commands.getoutput(comando)
		self.ControlTablaOdsms()

	def LoadPhoneID(self):
		self.listaPhoneID = {}
		for modem in MODEMS:
			comando = "cat "+modem+" | grep '^PhoneID' | tr -cd '[[:digit:]]'"
			print comando
			self.listaPhoneID[modem] = str(commands.getoutput(comando))
		
		
		
	def Control(self):
		print "------------------------------------------"
		print "<<Control>>"
		print
		
		#>0) Verificar los demonios gammu
		print chr(27)+"[0;36m"+"<<Control de demonios gammu de los modems (no debe haber) >>"+chr(27)+"[0m"
		cont = -1
		for modem in self.listaModems:
			cont = cont + 1
			comando = "ps axu | grep "+self.listaPIDS[cont]+" | grep -v grep | wc -l"
			cantidad_procesos = int(commands.getoutput(comando))
			if cantidad_procesos==0:
				#> para controlar que los demonios gammu esten arriba
				#print "Se procede a inidicar el pid "+self.listaPIDS[cont]+" que se encontraba caido" 
				#comando = "/opt/gammu/gammu-1.34.0/build/smsd/gammu-smsd --config "+modem+" --pid "+self.listaPIDS[cont]+" --daemon"
				#commands.getoutput(comando)
				
				#> para controlar que los demonios gammu esten abajo
				comando = "ps axu | grep '"+modem+"' | grep 'gammu-smsd' | grep -v grep | awk '{print $2}'"
				#print comando
				id_proceso = str(commands.getoutput(comando))
				if str(id_proceso)=="":
					print "OK: demonio gammu "+self.listaPIDS[cont]+" se encuentra detenido"
				else:
					comando = "kill "+id_proceso
					print "ERROR: demonio gammu "+self.listaPIDS[cont]+" se encuentra arriba"
					print "...Deteniendo demonio gammu ...OK"
					commands.getoutput(comando)
		
		#>1) Verificar que el nodo sea el correcto:
		print
		print chr(27)+"[0;36m"+"<<Control de ip>>"+chr(27)+"[0m"
		comando = "ifconfig | grep ':"+NODO_IP+" ' | wc -l"
		#print comando
		flag_nodo_ok = int(commands.getoutput(comando))
		if flag_nodo_ok == 1: 
			print "NODO_IP - OK!"
		elif self.h_alerta_enviada > int( int(time.time())+ PERIODO_ALERTAS ):
			self.h_alerta_enviada = int(time.time())
			mensaje = "*Error: La ip configurada ("+NODO_IP+") es incorrecta. Exit"
			self.AlertaMail(mensaje, "SMS-ERROR", "ALERTA")
			self.EnviarSms(mensaje,"ITERAR",FAIL_CONTACTAR_CELU, "ALERTA")
			sys.exit()
		
		#>2) Verificar que la cantidad de instancias del demonio sea una sola
		print
		print chr(27)+"[0;36m"+"<<Control de cantidad de instancias de si mismo>>"+chr(27)+"[0m"
		comando = "ps axu | grep demonio-"+NOMBRE_DEMONIO+".py | grep -v grep | wc -l"
		cantidad_procesos = int(commands.getoutput(comando))
		if cantidad_procesos == 1:
			print "Cantidad de instancias - OK"
		elif int( int(time.time()) - int(self.h_alerta_enviada) ) > int( PERIODO_ALERTAS ):
			self.h_alerta_enviada = int(time.time() )
			mensaje = "*Error: Hay "+str(cantidad_procesos)+" instancias del demonio. Exit"
			self.AlertaMail(mensaje, "SMS-ERROR", "ALERTA")
			self.EnviarSms(mensaje,"ITERAR",FAIL_CONTACTAR_CELU, "ALERTA")
			sys.exit()
		
		#>3) Verificar estado de los modems, ante una falla proceder a actualizar el estado del modem y enviar un email de Alerta
		print
		print chr(27)+"[0;36m"+"<<Control de modems On (tty) >>"+chr(27)+"[0m"
		for modem in self.listaModems:
			comando = "cat "+modem+" | grep device | cut -c13-200"
			#print comando
			tty = commands.getoutput(comando)
			comando = "ls /dev/ | grep '^"+tty+"$' | wc -l"
			#print comando
			tty_status = int(commands.getoutput(comando))
			
			#print "self.h_alerta_enviada: "+str(self.h_alerta_enviada)
			#print "int(time.time())+ PERIODO_ALERTAS: "+str( int(time.time())+ PERIODO_ALERTAS )
			
			if tty_status==0:
				if modem in self.listaModems and modem not in self.listaModemsOff:
					self.listaModemsOff.append(modem) 
				if int( int(time.time()) - int(self.h_alerta_enviada) ) > int( PERIODO_ALERTAS ):
					self.h_alerta_enviada = int(time.time())
					mensaje = "*ERROR: El dispositivo "+tty+" no se encuentra"
					self.AlertaMail(mensaje, "SMS-ERROR", "ALERTA")
					self.EnviarSms(mensaje,"ITERAR",FAIL_CONTACTAR_CELU, "ALERTA")
			else:
				print "OK: dispositivo "+tty+" activo"
			
			#> controlo los envios de cada modem
			sql = "select COUNT(*) from odsms where modem='"+ modem +"' AND \"fecha\" between now() - interval '10 min' and now();"
			#print sql
			for row in self.Query(sql,0,'SELECT'):
				if row[0] > FAIL_CANT_SEND:
					if modem in self.listaModems and modem not in self.listaModemsOff:
						print "DEBIDO A QUE EL MODEM DA ERROR EN MUCHOS SMS, SE DA DE BAJA MOMENTANEAMENTE"
						self.listaModemsOff.append(modem) 
		
		
		print
		print chr(27)+"[0;36m"+"<<Control de modems off (tty) >>"+chr(27)+"[0m"
		#print "QUITO MODEMS ON que se encuentran en MODEMS OFF"
		for modem in self.listaModemsOff:
			try:
				self.listaModems.remove(modem)
			except ValueError:
				pass  # do nothing!
		
		#>4) Verificar el estado de los modems caidos y restaurarlos en caso de que el modem se recupere
		for modem in self.listaModemsOff:
			comando = "cat "+modem+" | grep device | cut -c13-200"
			#print comando
			tty = commands.getoutput(comando)
			comando = "ls /dev/ | grep '^"+tty+"$' | wc -l"
			#print comando
			tty_status = int(commands.getoutput(comando))
			print "tty_status: "+str(tty_status)
			if tty_status==1:
				print "El "+tty+" se observa OK"
				if modem in self.listaModemsOff and modem not in self.listaModems:
					print "restauro TTY:"+tty+" correspondiente al MODEM: "+modem
					self.listaModems.append(modem)
				if int( int(time.time()) - int(self.h_alerta_enviada) ) > int( PERIODO_ALERTAS ):
					self.h_alerta_enviada = int(time.time())
					mensaje = "*OK: El dispositivo "+tty+" se encuentra recuperado OK"
					self.AlertaMail(mensaje, "SMS-OK", "MENSAJE")
					if self.EnviarSms(mensaje,"ITERAR",FAIL_CONTACTAR_CELU, "ALERTA"):
						print "envio sms OK"
		
		#print "QUITO MODEMS OFF que se encuentran en MODEMS ON"
		for modem in self.listaModems:
			try:
				self.listaModemsOff.remove(modem)
			except ValueError:
				pass  # do nothing!
		
		#>5) Verificar sms enviados en los ultimos 10 min, si la cantidad de errores supera a "FAIL_CANT_SEND", enviar alerta de mail y actualizar listas de modems
		print
		print chr(27)+"[0;36m"+"<<Control de ultimos sms enviados >>"+chr(27)+"[0m"
		connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
		cursor = connection.cursor()
		sql="select count(*) from outbox where \"InsertIntoDB\" between now() - interval '10 min' and now();"
		#print sql
		cursor.execute(sql)
		resultados = cursor.fetchall()
		for row in resultados:
			intentos_fallidos = row[0]
			if intentos_fallidos > FAIL_CANT_SEND:
				if int( int(time.time()) - int(self.h_alerta_enviada) ) > int( PERIODO_ALERTAS ):
					self.h_alerta_enviada = int(time.time())
					mensaje = "*ERROR: Se han alcanzado "+ str(intentos_fallidos) +" en los ultimos 10 minutos"
					self.AlertaMail(mensaje, "SMS-ERROR", "ALERTA")
					self.EnviarSms(mensaje,"ITERAR",FAIL_CONTACTAR_CELU, "ALERTA")
			else:
				print "OK: No hay fallas masivas (superior al limite 'FAIL_CANT_SEND')"
		connection.close()

		print "ESTADO DE MODEMS TRAS CONTROL:"
		print "### MODEMS ON: "+str(self.listaModems)
		print "### MODEMS OFF: "+str(self.listaModemsOff)
		time.sleep(INTERVALO_ENVIOS)
		
		print "------------------------------------------"
	
	def ConectarDB(self):
		print "<<ConectarDB>>"
		self.connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
		self.cursor = self.connection.cursor()
	
	def CerrarDB(self):
		print "<<CerrarDB>>"
		if self.connection:
			self.connection.close()
	
	#> tipo: ALERTA/MENSAJE
	def AlertaMail(self, mensaje, asunto, tipo):
		print "<<AlertaMail>>"
		f_enviar = 1
		if tipo=="ALERTA" and FLAG_CONTACTAR_EMAIL_ERROR==0:
			f_enviar = 0
		if f_enviar == 1:
			comando = "echo -e \""+mensaje+"\" | mailx -s \""+asunto+" / "+CLIENTE+"\" "+CONTACTAR_EMAIL+""
			print comando
			commands.getoutput(comando)
	
	def RecibirSms(self):
		print chr(27)+"[0;26m"+"<<RecibirSms>>"+chr(27)+"[0m"
		for modem in self.listaModems:
			print "#> Recepcion desde modem: <"+ modem +">"
			comando = "/opt/gammu/gammu-1.34.0/build/smsd/gammu-smsd --config "+ modem +" --suicide=11" #20
			print comando
			commands.getoutput(comando)
			print "#> Fin de Recepcion desde modem: <"+ modem +">\n"
	
	def EnviarSms(self,mensaje,modem,destino,tipo):
		print chr(27)+"[0;16m"+"<<EnviarSms>>"+chr(27)+"[0m"
		print "LISTA DE MODEMS:"
		print self.listaModems
		print "LISTA DE MODEMS OFF:"
		print self.listaModemsOff
		self.lastSMSout_celu = destino
		self.lastSMSout_codigo = ''
		self.lastSMSout_modem = ''
		self.lastSMSout_resp = ''
			
		self.contadorEnvios = self.contadorEnvios + 1
		if self.contadorEnvios >= DORMIR_CANT:
			time.sleep(DORMIR_TIME)
			self.contadorEnvios = 0
		
		print "self.listaModems: "+str(self.listaModems)
		if len(self.listaModems)==0:
			print "NO HAY MODEMS!"
			self.lastSMSout_resp = "NO HAY MODEMS!"
			self.lastSMSout_codigo = '-2'
			return False
		else:
			#>Con el parametro "ITERAR" se indica que el sistema va interando entre los modems
			if modem == "ITERAR":
				if int(self.indiceModem+1)>=len(self.listaModems) and len(self.listaModems)>0:
					self.indiceModem = 0
				else:
					self.indiceModem = self.indiceModem + 1
				
				print "SE SELECCIONA EL ID "+str(self.indiceModem)
				
				if self.indiceModem < len(self.listaModems):
					print self.listaModems
					modem = self.listaModems[self.indiceModem]
					print "SMS enviado por modem "+modem
				else:
					print "NO HAY MODEMS! NO VEO EL INDICE EN LA LISTA DE MODEMS!"
					print self.listaModems
					self.lastSMSout_codigo = '-2'
					return False
			
			f_enviar = 1
			if tipo=="ALERTA" and FLAG_CONTACTAR_SMS_ERROR==0:
				f_enviar = 0
			if f_enviar == 1:
				#> Esto es para enviar con inject en la tabla gammu y que posteriormente el demonio de gammu lo envie
				#> comando = "echo '"+mensaje+"' |  /opt/gammu/gammu-1.34.0/build/smsd/gammu-smsd-inject --config "+modem+" TEXT "+destino
				#> Esto es para enviar con comando directamente mediante gammu
				comando = "timeout 50 "+RUTA+"smsgo.sh '"+str(mensaje)+"' "+str(self.listaPhoneID[modem])+" "+destino
				print comando
				
				self.lastSMSout_resp = commands.getoutput(comando)
				self.lastSMSout_modem = modem
				print chr(27)+"RESPUESTA AL ENVIO DEL SMS:"+chr(27)+"[0m"
				print chr(27)+str(self.lastSMSout_resp)+chr(27)+"[0m"
				
				if self.lastSMSout_resp.find("answer..OK") >= 0:
					self.lastSMSout_codigo = '1'
				elif self.lastSMSout_resp.find("Aceptar, referencia de mensaje") >= 0:
					self.lastSMSout_codigo = '1'
				else:
					self.lastSMSout_codigo = '-1'
				
			print "fin enviar sms"
			return True
	
	def sattoloCycle(items):
		from random import randrange
		i = len(items)
		while i > 1:
			i = i - 1
			j = randrange(i)  # 0 < = j <= i-1
			items[j], items[i] = items[i], items[j]
		return
	
	def Query(self, sql, f_print, tipo):
		try:
			if f_print==1:
				print
				print "<sql> : ### "+sql+" ###"
				print
			#self.ConectarDB() #conecto
			self.cursor.execute(sql)
			if tipo == 'SELECT':
				return self.cursor.fetchall()
			elif tipo == 'UPDATE':
				self.connection.commit()
			#self.CerrarDB() #desconecto
		except psycopg2.DatabaseError, e:
			print 'Error %s' % e 
			self.CerrarDB()
			sys.exit(1)
		finally:
			print "---"

	def Query2(self, sql, f_print, tipo):
		try:
			if f_print==1:
				print
				print "<sql> : ### "+sql+" ###"
				print
			connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
			cursor = connection.cursor()
			cursor.execute(sql)
			if tipo == 'SELECT':
				return cursor.fetchall()
			elif tipo == 'UPDATE':
				connection.commit()
				#comando = 'python actualizar_camp.py "'+sql+'"'
				#print commands.getoutput(comando)
			connection.close() #desconecto
		except psycopg2.DatabaseError, e:
			print 'Error %s' % e 
			connection.close()
			sys.exit(1)
		finally:
			print "---"

	def ControlTablaOdsms(self):
		### PARA EL CONTROL DE SMS SALIENTES SE CREA LA TABLA 'odsms'
		f_crear_tabla_odsms = 1
		sql = "select 1 from pg_tables where tablename='odsms';"
		for row in self.Query(sql,0,'SELECT'):
			if row[0] == 1:
				f_crear_tabla_odsms = 0
		if f_crear_tabla_odsms == 1:
			sql = " CREATE TABLE \"odsms\" ( \"id\" SERIAL PRIMARY KEY, \"id_camp\" int  NOT NULL, \"id_contacto\" int NOT NULL, \"fecha\" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP, \"nombre_camp\" varchar(50) NOT NULL, \"numero\" varchar(30)NOT NULL, \"estado\" int NOT NULL, \"calificacion\" varchar(200) NOT NULL, \"modem\" varchar(100) NOT NULL );"
			self.Query(sql,1,'UPDATE')			
		
	def ProcesarCamp(self):
		listaSMS = []
		listaCamp = []
		
		hoy_dia = time.strftime("%a")
		#>Domingo
		if   hoy_dia=='Sun': DIA = '6'
		elif hoy_dia=='Mon': DIA = '0'
		elif hoy_dia=='Tue': DIA = '1'
		elif hoy_dia=='Wed': DIA = '2'
		elif hoy_dia=='Thu': DIA = '3'
		elif hoy_dia=='Fri': DIA = '4'
		elif hoy_dia=='Sat': DIA = '5'
		print '\n\n\n\nDIA:'+DIA
		
		#>1) Buscar celulares en la base de datos con fecha actual
		sql=" SELECT A.id, A.bd_contacto_id, A.cantidad_chips, A.template_mensaje,  A.template_mensaje_opcional, A.template_mensaje_alternativo, C.metadata, A.nombre  "
		sql+=" from fts_web_campanasms A JOIN fts_web_actuacionsms B ON A.id=B.campana_sms_id JOIN fts_web_basedatoscontacto C ON A.bd_contacto_id=C.id "
		sql+=" WHERE A.estado=2 AND now() BETWEEN A.fecha_inicio AND A.fecha_fin + interval '24 HOURS' AND now() BETWEEN to_timestamp(CONCAT(date(now()),' ',B.hora_desde),'YYYY-MM-DD HH24:MI') AND to_timestamp(CONCAT(date(now()),' ',B.hora_hasta),'YYYY-MM-DD HH24:MI')  AND B.dia_semanal="+DIA+" ;"
		resultados = self.Query(sql,0,'SELECT')
		for row in resultados:
			#> print "A.id = "+str(row[0])
			listaCamp.append([ { 'id_camp':str(row[0]), 'bd_contacto_id':str(row[1]), 'cantidad_chips':str(row[2]), 'mensaje_principal':str(row[3]), 'mensaje_opcional':str(row[4]), 'mensaje_alternativo':str(row[5]), 'metadata':str(row[6]), 'nombre_camp':str(row[7]) } ])
		
		print "LISTA DE CAMPANIAS EN HORARIO:"
		print listaCamp
		
		for camp in listaCamp:
			#> print camp[0]['id_camp']
			#> print camp[0]['bd_contacto_id']
			#> print camp[0]['cantidad_chips']
			#> print camp[0]['mensaje']
			#> print camp[0]['metadata']
			#> print camp[0]['nombre_camp']
			#> reemplazar true por True!!!
			camp[0]['metadata'] = camp[0]['metadata'].replace(': true,', ': True,', 1)

			limit = str(BUFER_SMS * int(camp[0]['cantidad_chips']))
			#print "CONSULTA PARA CARGAR CLIENTES A CONTACTAR"
			sql = "select id, datos from fts_web_contacto_"+ str(camp[0]['id_camp']) +" WHERE bd_contacto_id="+ str(camp[0]['bd_contacto_id']) +" AND (sms_enviado=0 OR sms_enviado=-1) AND cant_intentos<"+str(MAX_INTENTOS)+" ORDER BY cant_intentos ASC limit "+ limit +";"
			#print sql
			for row in self.Query(sql,0,'SELECT'):
				#>print "campo datos: %s" % (row[1])
				contacto_id = row[0]
				lista_datos = eval(row[1])
				destino = str(eval(row[1])[0])
				#>print "lista_datos: "+str(lista_datos)
				
				diccionario_metadata = eval( camp[0]['metadata'] )
				cont = -1
				#mensaje = camp[0]['mensaje']
				mensaje = self._random_mensajes(camp[0]['mensaje_principal'], camp[0]['mensaje_opcional'], camp[0]['mensaje_alternativo'])
				for columna in diccionario_metadata['nombres_de_columnas']:
					cont = cont + 1
					#>print str(cont)+": "+columna+" -> "+lista_datos[cont]
					mensaje = mensaje.replace( '$'+columna+'', str(lista_datos[cont]) )
				
				listaSMS.append([ {'id_camp':camp[0]['id_camp'], 'id_contacto':contacto_id, 'bd_contacto_id':camp[0]['bd_contacto_id'], 'cantidad_chips':camp[0]['cantidad_chips'], 'mensaje':mensaje, 'destino':destino, 'nombre_camp':camp[0]['nombre_camp']} ])
		
		random.shuffle(listaSMS)
		#print "listaSMS: "+str(listaSMS)	

		contador_sms = 0
		contador_hilos = 0
		for dato_sms in listaSMS:
			contador_hilos = contador_hilos + 1
			if contador_hilos == 1:
				threads = list()			
			elif contador_hilos > len(self.listaModems):
				contador_hilos = 1
			
			print "> contador_hilos:"+str(contador_hilos)
			print "> Cantidad de Threads activos: "+str( threading.activeCount() )
			
			if len(self.listaModems)==0:
				modem_usar = 'ITERAR'
			else:
				modem_usar = self.listaModems[(contador_hilos-1)]
				
			print "*** modem_usar="+modem_usar+" ***"
			
			t = threading.Thread(target=self.EnviarSmsThread, args=(dato_sms[0]['mensaje'],modem_usar,dato_sms[0]['destino'],'CAMPANA',str(dato_sms[0]['id_camp']),str(dato_sms[0]['id_contacto']),dato_sms[0]['nombre_camp'],), name='HILO'+str(contador_hilos)+'_'+str(modem_usar) )
			threads.append(t)
			t.start() #con esto inicia el hilo
			if contador_hilos==len(self.listaModems) or contador_hilos==len(listaSMS) or len(self.listaModems)==0:
				time.sleep(INTERVALO_ENVIOS)
			
			print ">>>> Cantidad de Threads activos: "+str( threading.activeCount() )

			contador_sms = contador_sms +1
			if contador_sms is 50:
				contador_sms = 0
				break
		
		while threading.activeCount() > 1:
			print ">>>> Espero a que terminen todos los threads"
			print ">>>> Cantidad de Threads activos: "+str( threading.activeCount() )
			time.sleep(1)

	def _random_mensajes(self, mensaje_principal, mensaje_opcional, mensaje_alternativo):
		""" Este metodo hace un random entre los 3 tipos de mensajes si existe
		    (opcional, alternativo) si no devuelve el mensaje_principal
		:return: devuelve el mensaje a enviar
		"""
		if mensaje_principal and mensaje_opcional and mensaje_alternativo:
			mensajes = (mensaje_principal, mensaje_opcional, mensaje_alternativo)
			mensaje = random.choice(mensajes)
			return mensaje
		elif mensaje_principal and mensaje_opcional:
			mensajes = (mensaje_principal, mensaje_opcional)
			mensaje = random.choice(mensajes)
			return mensaje
		elif mensaje_principal and  mensaje_alternativo:
			mensajes = (mensaje_principal, mensaje_alternativo)
			mensaje = random.choice(mensajes)
			return mensaje
		elif mensaje_principal:
			return mensaje_principal
		else:
			return None

	
	def EnviarSmsThread(self,mensaje,modem,destino,tipo,id_camp,id_contacto,nombre_camp):
		print chr(27)+"[0;46m",threading.currentThread().getName()+' Lanzado'+chr(27)+"[0m"
		
		print "_____ PARAMETROS _______"
		print "| modem:"+modem
		print "| destino:"+destino
		print "| id_contacto:"+id_contacto
		print "_________________________"
		
		#> SMSout_codigo puede recibir uno de los siguientes valores:
		#> -1 : Error en el envio
		#>  0 : Mensaje no procesado aun
		#>  1 : Mensaje enviado OK
		#> -2 : No hay modems activos
		
		print chr(27)+"[0;16m"+"<<EnviarSmsThread>>"+chr(27)+"[0m"
		print "LISTA DE MODEMS:"
		print self.listaModems
		print "LISTA DE MODEMS OFF:"
		print self.listaModemsOff
		SMSout_celu = destino
		SMSout_codigo = ''
		SMSout_modem = ''
		SMSout_resp = ''
			
		self.contadorEnvios = self.contadorEnvios + 1
		if self.contadorEnvios >= DORMIR_CANT:
			time.sleep(DORMIR_TIME)
			self.contadorEnvios = 0
		
		print "self.listaModems: "+str(self.listaModems)
		if len(self.listaModems)==0:
			print "NO HAY MODEMS!"
			SMSout_resp = "NO HAY MODEMS!"
			SMSout_codigo = '-2'
			return False
		else:
			#>Con el parametro "ITERAR" se indica que el sistema va interando entre los modems
			if modem == "ITERAR":
				if int(self.indiceModem+1)>=len(self.listaModems) and len(self.listaModems)>0:
					self.indiceModem = 0
				else:
					self.indiceModem = self.indiceModem + 1
				
				print "SE SELECCIONA EL ID "+str(self.indiceModem)
				
				if self.indiceModem < len(self.listaModems):
					print self.listaModems
					modem = self.listaModems[self.indiceModem]
					print "SMS enviado por modem "+modem
				else:
					print "NO HAY MODEMS! NO VEO EL INDICE EN LA LISTA DE MODEMS!"
					print self.listaModems
					SMSout_codigo = '-2'
			
			f_enviar = 1
			if tipo=="ALERTA" and FLAG_CONTACTAR_SMS_ERROR==0:
				f_enviar = 0
			if f_enviar == 1:
				#> Esto es para enviar con inject en la tabla gammu y que posteriormente el demonio de gammu lo envie
				#> comando = "echo '"+mensaje+"' |  /opt/gammu/gammu-1.34.0/build/smsd/gammu-smsd-inject --config "+modem+" TEXT "+destino
				#> Esto es para enviar con comando directamente mediante gammu
				comando = "timeout 60 "+RUTA+"smsgo.sh '"+str(mensaje)+"' "+str(self.listaPhoneID[modem])+" "+destino
				print comando
				
				SMSout_resp = commands.getoutput(comando)
				SMSout_modem = modem
				print chr(27)+"RESPUESTA AL ENVIO DEL SMS:"+str(SMSout_resp)+chr(27)+"[0m"
				
				if SMSout_resp.find("answer..OK") >= 0:
					SMSout_codigo = '1'
				elif SMSout_resp.find("Aceptar, referencia de mensaje") >= 0:
					SMSout_codigo = '1'
				else:
					SMSout_codigo = '-1'
				
			print "Fin del envio "+str(modem)
		
		if SMSout_celu == str(destino) and SMSout_codigo!=-2:
			sql = "UPDATE fts_web_contacto_"+ str(id_camp) +" SET sms_enviado="+ str(SMSout_codigo) +", sms_enviado_fecha=now(), cant_intentos=(cant_intentos+1) WHERE id="+ str(id_contacto) +""			
			print
			print "sql_update_sms: "+sql
			print
			self.Query2(sql,1,'UPDATE')
		else:
			print "CASO B: (no hay modems activos)"
			print "self.lastSMSout_codigo = "+str(SMSout_codigo)
		sql = "INSERT INTO odsms (id_camp, id_contacto, nombre_camp, numero, estado, calificacion, modem) VALUES ( "+str(id_camp)+", "+str(id_contacto)+", '"+nombre_camp+"', '"+str(destino)+"', "+ str(SMSout_codigo) +", '"+ SMSout_resp +"', '"+ SMSout_modem +"' );"
		self.Query2(sql,1,'UPDATE')
		print chr(27)+"[0;46m"+threading.currentThread().getName()+' Detenido'+chr(27)+"[0m"
	
	
	def Ejecutar(self):
		print "\n\n\n\@@@ INICIA @@@\n"
		while threading.activeCount() > 1:
			print "@@@ Espero a que terminen todos los threads"
			print "@@@ Cantidad de Threads activos: "+str( threading.activeCount() )
			time.sleep(1)
		os.chdir(RUTA[:-1])
		contador = -1
		while 1:
			print "@@@ nueva vuelta"
			contador = contador + 1
			if contador%1==0:
				self.Control()
			if contador%10==0:
				from hot_settings import *
				self.RecibirSms()
				self.LoadPhoneID()
				hora = int(  time.strftime("%H")  )
			if hora>=HR_INICIO and hora<HR_FIN:
				if contador%10==0:
					print "Verificando conexion"
					self.ConectarDB()
				self.ProcesarCamp()
				time.sleep(3)
			else:
				time.sleep(200)
				print "fuera de hora"
			#>exit()

def start():
	sms = SMS()
	sms.Ejecutar()

#>start()

