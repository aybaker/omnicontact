#!/usr/bin/python
# -*- coding: utf8 -*-

#> importar constantes
from constantes import *

#> para conexion con postgreeSQL
import psycopg2

import socket
import string
import commands

import time
import MySQLdb
import os
import datetime
from time import gmtime, strftime

import smtplib
import mimetypes
from email.MIMEText import MIMEText
from email.Encoders import encode_base64

import math
import sys

listaModems = ['/etc/gammu-smsdrc', '/etc/gammu-smsdrc-1']
listaModemsOff = []

for modem in listaModems:
	print modem

print listaModems
print listaModemsOff
print
print
for modem in listaModems:
	comando = "cat "+modem+" | grep device | cut -c13-200"
	print comando
	tty = commands.getoutput(comando)
	comando = "ls /dev/ | grep '^"+tty+"$' | wc -l"
	print comando
	tty_status = int(commands.getoutput(comando))
	if tty_status==0:
		#quito el modem del listado de modems ok
		listaModemsOff.append(modem) 
		mensaje = "*ERROR: El dispositivo "+tty+" no se encuentra"
	else:
		print "dispositivo "+tty+" - OK"

for modem in listaModemsOff:
	listaModems.remove(modem)
		
print
print
print listaModems
print listaModemsOff