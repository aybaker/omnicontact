#!/bin/bash

modem=$1
destino=$2
mensaje=$3

echo "${mensaje}" |  /opt/gammu/gammu-1.34.0/build/smsd/gammu-smsd-inject --config ${modem} TEXT ${destino}