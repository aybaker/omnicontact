#!/usr/bin/python
# -*- coding: utf8 -*-

import psycopg2
import socket
import string
import commands
import time
import os
import datetime
from time import gmtime, strftime
import math
import sys
import random

def Query(sql, f_print, tipo):
	try:
		if f_print==1:
			print
			print "<sql> : ### "+sql+" ###"
			print
		self.cursor.execute(sql)
		if tipo == 'SELECT':
			return self.cursor.fetchall()
		elif tipo == 'UPDATE':
			self.connection.commit()
	except psycopg2.DatabaseError, e:
		print 'Error %s' % e 
		sys.exit(1)
	finally:
		print "---"
			
			
DB_HOST = '127.0.0.1'
DB_PORT = '5432'
DB_USER = 'ftsender'
DB_PASS = 'Freetech123'
DB_BASE = 'ftsender'

DB_HOST_gammu = '127.0.0.1'
DB_PORT_gammu = '5432'
DB_USER_gammu = 'smsd'
DB_PASS_gammu = 'smsd'
DB_BASE_gammu = 'smsd'

print ">>>>>>MIRAR CANTIDAD DE MENSAJES QUE QUEDAN POR ENVIAR (outbox)"
INTERVAL = '100'
limit = '10'
connection_gammu = psycopg2.connect(database=DB_BASE_gammu, user=DB_USER_gammu, password=DB_PASS_gammu, host=DB_HOST_gammu, port=DB_PORT_gammu)
cursor_gammu = connection_gammu.cursor()
sql="select count(*) from outbox where \"InsertIntoDB\" between now() - interval '"+ INTERVAL +" min' and now();"
cursor_gammu.execute(sql)
resultados = cursor_gammu.fetchall()
for row in resultados:
	intentos_fallidos = row[0]
	mensaje = "*ERROR: Se han alcanzado "+ str(intentos_fallidos) +" intentos fallidos en los ultimos "+ INTERVAL +" minutos"
	print mensaje

cursor_gammu.execute("Select * FROM sentitems")
colnames = [desc[0] for desc in cursor_gammu.description]
print colnames

sql="select * from outbox order by \"InsertIntoDB\" desc limit "+limit+";"
cursor_gammu.execute(sql)
resultados = cursor_gammu.fetchall()
for row in resultados:
	print row
connection_gammu.close()
print
print






print ">>>>>>MIRAR CANTIDAD DE MENSAJES ENVIADOS (sentitems)"
INTERVAL = '200'
limit = '3'
connection_gammu = psycopg2.connect(database=DB_BASE_gammu, user=DB_USER_gammu, password=DB_PASS_gammu, host=DB_HOST_gammu, port=DB_PORT_gammu)
cursor_gammu = connection_gammu.cursor()
sql="select count(*) from sentitems where \"InsertIntoDB\" between now() - interval '"+ INTERVAL +" min' and now() + interval '"+ INTERVAL +" min' ;"
cursor_gammu.execute(sql)
resultados = cursor_gammu.fetchall()
for row in resultados:
	intentos_fallidos = row[0]
	mensaje = "*OK: Se han enviado "+ str(intentos_fallidos) +" sms en los ultimos "+ INTERVAL +" minutos"
	print mensaje

	
cursor_gammu.execute("Select * FROM sentitems")
colnames = [desc[0] for desc in cursor_gammu.description]
print colnames

sql="select * from sentitems order by \"InsertIntoDB\" desc limit "+limit+";"
cursor_gammu.execute(sql)
resultados = cursor_gammu.fetchall()
for row in resultados:
	print str(row)
connection_gammu.close()
print
print






limit = "3"
print ">>>>>>MIRAR TABLAS DE CAMPANIAS SMS EN ACTUACION (fts_web_contacto_<(id de fts_web_campanasms)>)"
connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
cursor = connection.cursor()

listaSMS = []
listaCamp = []

hoy_dia = time.strftime("%a")
if   hoy_dia=='Sun': DIA = '6' #Domingo
elif hoy_dia=='Mon': DIA = '0'
elif hoy_dia=='Tue': DIA = '1'
elif hoy_dia=='Wed': DIA = '2'
elif hoy_dia=='Thu': DIA = '3'
elif hoy_dia=='Fri': DIA = '4'
elif hoy_dia=='Sat': DIA = '5'
print 'DIA:'+DIA

#1) Buscar celulares en la base de datos con fecha actual
sql="SELECT A.id, A.bd_contacto_id, A.cantidad_chips, A.template_mensaje, C.metadata  "
sql+=" from fts_web_campanasms A JOIN fts_web_actuacionsms B ON A.id=B.campana_sms_id JOIN fts_web_basedatoscontacto C ON A.bd_contacto_id=C.id "
sql+=" WHERE A.estado=2 AND now() BETWEEN A.fecha_inicio AND A.fecha_fin + interval '24 HOURS' AND now() BETWEEN to_timestamp(CONCAT(date(now()),' ',B.hora_desde),'YYYY-MM-DD HH24:MI') AND to_timestamp(CONCAT(date(now()),' ',B.hora_hasta),'YYYY-MM-DD HH24:MI')  AND B.dia_semanal="+DIA+" ;"
print sql
try:
	cursor.execute(sql)
	resultados = cursor.fetchall()
except psycopg2.DatabaseError, e:
	print 'Error %s' % e 
	sys.exit(1)
for row in resultados:
	#print "A.id = "+str(row[0])
	listaCamp.append([ { 'id_camp':str(row[0]), 'bd_contacto_id':str(row[1]), 'cantidad_chips':str(row[2]), 'mensaje':str(row[3]), 'metadata':str(row[4]) } ])

print listaCamp
for camp in listaCamp:
	#print camp[0]['id_camp']
	#print camp[0]['bd_contacto_id']
	#print camp[0]['cantidad_chips']
	#print camp[0]['mensaje']
	#print camp[0]['metadata']
	#reemplazar true por True!!!
	camp[0]['metadata'] = camp[0]['metadata'].replace(': true,', ': True,', 1)
		
	print ">>>>>>>>>>>>>>>>>>>>>>> CAMP: fts_web_contacto_"+ str(camp[0]['id_camp'])
	sql = "select id, datos, sms_enviado, sms_enviado_fecha from fts_web_contacto_"+ str(camp[0]['id_camp']) +" limit "+ str(limit) +";"
	cursor.execute(sql)
	resultados = cursor.fetchall()
	for row in resultados:
		#print "campo datos: %s" % (row[1])
		contacto_id = str(row[0])
		lista_datos = eval(row[1])
		destino = str(eval(row[1])[0])
		#print "destino = "+str(destino)
		sms_enviado = str(row[2])
		sms_enviado_fecha = str(row[3])
		
		

		diccionario_metadata = eval( camp[0]['metadata'] )
		
		print
		print "@@@ mensaje antes="+str(camp[0]['mensaje'])
		print
		
		#print
		#print "lista_datos:"
		#print lista_datos
		#print
		#print		
		
		#print
		#print "diccionario_metadata:"
		#print diccionario_metadata['nombres_de_columnas']
		#print
		#print
		
		cont = -1
		mensaje = camp[0]['mensaje']
		for columna in diccionario_metadata['nombres_de_columnas']:
			cont = cont + 1
			print str(cont)+": "+columna+" -> "+lista_datos[cont]
			mensaje = mensaje.replace( '$'+columna+'', str(lista_datos[cont]) )
		
		print
		print "@@@ mensaje ahora="+mensaje
		print
		
		print "id: "+contacto_id+" | datos:"+str(lista_datos)+" | enviado:"+sms_enviado+" | fecha:"+sms_enviado_fecha+" | destino:"+destino
		listaSMS.append([ {'id_camp':camp[0]['id_camp'], 'id_contacto':contacto_id, 'bd_contacto_id':camp[0]['bd_contacto_id'], 'cantidad_chips':camp[0]['cantidad_chips'], 'mensaje':mensaje, 'destino':destino} ])

random.shuffle(listaSMS)
#print "listaSMS"+str(listaSMS)
		
connection.close()
print
print


