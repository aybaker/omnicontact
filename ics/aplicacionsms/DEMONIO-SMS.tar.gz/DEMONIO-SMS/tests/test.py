#!/usr/bin/python
# -*- coding: utf8 -*-

import psycopg2

DB_HOST_gammu = '127.0.0.1'
DB_PORT_gammu = '5432'
DB_USER_gammu = 'smsd'
DB_PASS_gammu = 'smsd'
DB_BASE_gammu = 'smsd'


connection_gammu = psycopg2.connect(database=DB_BASE_gammu, user=DB_USER_gammu, password=DB_PASS_gammu, host=DB_HOST_gammu, port=DB_PORT_gammu)
cursor_gammu = connection_gammu.cursor()


sql="select count(*) from outbox where \"InsertIntoDB\" between now() - interval '10 min' and now();"
cursor_gammu.execute(sql)

resultados = cursor_gammu.fetchall()
for row in resultados:
	print row[0]


connection_gammu.close()



print
print
print
print
print
print







import string

#listaSMS = [('152397172', 'hola mundo', 34, 888),('153915881', 'hola yuli', 35, 9999),('123456', 'hola gato', 35, 9999),('987654', 'hola pesho', 35, 9999)]

#print listaSMS.pop()

#print listaSMS

#import random
#random.shuffle(listaSMS)


#print listaSMS



listaCamp = []
listaCamp.append([ {'id_camp':"A.id", 'bd_contacto_id':"A.bd_contacto_id", 'mensaje':"A.template_mensaje", 'cantidad_chips':"A.cantidad_chips"} ])
listaCamp.append([ {'id_camp':"A.id2", 'bd_contacto_id':"A.bd_contacto_id2", 'mensaje':"A.template_mensaje2", 'cantidad_chips':"A.cantidad_chips2"} ])

print listaCamp

for camp in listaCamp:
	print camp[0]['id_camp']
	print camp[0]['bd_contacto_id']

print listaCamp.pop()

for camp in listaCamp:
	print camp[0]['id_camp']
	print camp[0]['bd_contacto_id']


