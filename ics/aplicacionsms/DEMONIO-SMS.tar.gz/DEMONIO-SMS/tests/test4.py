#!/usr/bin/python
# -*- coding: utf8 -*-

import psycopg2
import socket
import string
import commands
import time
import os
import datetime
from time import gmtime, strftime
import math
import sys
import random

DB_HOST = '127.0.0.1'
DB_PORT = '5432'
DB_USER = 'ftsender'
DB_PASS = 'Freetech123'
#DB_PASS = 'ivujfakCiph9cyGhocfonn7'
DB_BASE = 'ftsender'

DB_HOST_gammu = '127.0.0.1'
DB_PORT_gammu = '5432'
DB_USER_gammu = 'smsd'
DB_PASS_gammu = 'smsd'
DB_BASE_gammu = 'smsd'

connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
cursor = connection.cursor()

#sql = "SELECT dblink_connect_u('host="+DB_HOST_gammu+" dbname="+DB_BASE_gammu+" user="+DB_USER_gammu+" password="+DB_PASS_gammu+" port=5432');"
#try:
#	cursor.execute(sql)
#	resultados = cursor.fetchall()
#except psycopg2.DatabaseError, e:
#	print 'Error %s' % e 
#	sys.exit(1)
#for row in resultados:
#	print "row[0]: = "+str(row[0])
	
	

sql = "select id from dblink('hostaddr="+DB_HOST_gammu+" dbname="+DB_BASE_gammu+" user="+DB_USER_gammu+" password="+DB_PASS_gammu+"','select ID from inbox')"
print sql
try:
	cursor.execute(sql)
	resultados = cursor.fetchall()
except psycopg2.DatabaseError, e:
	print 'Error %s' % e 
	sys.exit(1)
for row in resultados:
	print "row[0]: = "+str(row[0])


sql = "SELECT ftsender.fts_web_contacto_19.id, ftsender.fts_web_contacto_19.datos, smsd.inbox.ID FROM fts_web_contacto_19 IN ftsender, inbox IN smsd WHERE ftsender.fts_web_contacto_19.id = smsd.inbox.ID;"
try:
	cursor.execute(sql)
	resultados = cursor.fetchall()
except psycopg2.DatabaseError, e:
	print 'Error %s' % e 
	sys.exit(1)
for row in resultados:
	print "row[0]: = "+str(row[0])
	
connection.close()




sql = """SELECT ftsender.id, ftsender.datos, s.ID 
        FROM ftsender.fts_web_contacto_19 INNER JOIN 
                dblink('dbname=smsd port=5432 host=127.0.0.1 
                user=smsd password=smsd',
                'SELECT ID FROM inbox')
            AS s(ID int)
             ON ftsender.id = s.ID;"""


