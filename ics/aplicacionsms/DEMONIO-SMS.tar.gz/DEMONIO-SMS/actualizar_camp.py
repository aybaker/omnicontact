#!/usr/bin/python
# -*- coding: utf8 -*-

from settings import *
from hot_settings import *

import psycopg2

import socket
import string
import commands

import time
import os
import datetime
from time import gmtime, strftime

import math
import sys

import random

import threading

if len(sys.argv) == 2:
	sql = sys.argv[1]
	
	connection = psycopg2.connect(database=DB_BASE, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
	cursor = connection.cursor()
	cursor.execute(sql)
	connection.commit()
