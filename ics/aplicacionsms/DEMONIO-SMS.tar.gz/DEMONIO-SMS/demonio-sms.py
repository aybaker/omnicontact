#!/usr/bin/python
# -*- coding: UTF8 -*-
###########################################################################
# configure these paths:

import settings
import hot_settings

from settings import *
from hot_settings import *

LOGFILE = '/var/log/demonio-'+NOMBRE_DEMONIO+'.log'
ERRORLOGFILE = '/var/log/demonio-'+NOMBRE_DEMONIO+'.err'
PIDFILE = '/var/run/demonio-'+NOMBRE_DEMONIO+'.pid'

import commands
crearsinoexiste(LOGFILE)
crearsinoexiste(ERRORLOGFILE)
	
# and let USERPROG be the main function of your project

import logica_sms
USERPROG = logica_sms.start

###########################################################################
#based on Jürgen Hermanns http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/66012
import sys, os, time

class Log:
    # file like for writes with auto flush after each write to ensure that everything is logged,
    # even during an unexpected exit.
    def __init__(self, f):
        self.f = f

    def write(self, s):
        # Gracias a Nubio por este condicional!!
        if s.strip() == '': return
        self.f.write('%s -- %s\n' % (time.ctime(), s))
        self.f.flush()

def main():
    sz = os.path.getsize( LOGFILE )
    base = 1024
    mesure = (sz<base and ['bytes'] or [(sz<base*1000 and ['kbytes'] or [(sz<base*1000000 and ['mbytes'] or ['gbytes'])[0]])[0]][0])
    print sz, mesure
    if int(sz) > 500000: sz = os.system("mv " + LOGFILE + " " + LOGFILE + ".1")
    
    sz = os.path.getsize( ERRORLOGFILE )
    base = 1024
    mesure = (sz<base and ['bytes'] or [(sz<base*1000 and ['kbytes'] or [(sz<base*1000000 and ['mbytes'] or ['gbytes'])[0]])[0]][0])
    print sz, mesure
    if int(sz) > 500000: sz = os.system("mv " + ERRORLOGFILE + " " + ERRORLOGFILE + ".1")
    
    #change to data directory if needed
    os.chdir("/")
 
    #redirect outputs to a logfile
    sys.stdout = Log(open(LOGFILE, 'a+'))
    sys.stderr = Log(open(ERRORLOGFILE, 'a+'))
 
    #ensure the that the daemon runs a normal user
    #set user and group first "pydaemon" 
    os.setegid(1000)
    os.seteuid(1000)

    #start the user program here:
    print "Comienza demonio "+NOMBRE_DEMONIO+""
    USERPROG()
    print "Finaliza demonio "+NOMBRE_DEMONIO+""

if __name__ == "__main__":
    # do the UNIX double-fork magic
    # see "Stevens Advanced Programming in the UNIX Environment"
    # for details (ISBN 0201563177)
    try: 
        pid = os.fork()
        if pid > 0:
            # exit first parent
            sys.exit(0)
    except OSError, e:
        print >>sys.stderr, "fork #1 failed: %d (%s)" % (e.errno, e.strerror)
        sys.exit(1)

    # decouple from parent environment and do not prevent unmounting
    os.chdir("/")
    os.setsid()
    os.umask(0)

    # do second fork
    try:
        pid = os.fork()
        if pid > 0:
            # exit from second parent, print eventual PID before
            open(PIDFILE,'w').write("%d"%pid)
            sys.exit(0)
    except OSError, e:
        print >>sys.stderr, "fork #2 failed: %d (%s)" % (e.errno, e.strerror)
        sys.exit(1)

    # start the daemon main loop
    main()

start()
