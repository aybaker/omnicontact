#!/usr/bin/python
# -*- coding: utf8 -*-




#/* CLIENTE: Identifica al cliente o plataforma*/
CLIENTE = 'Cliente-1'

DB_HOST = '127.0.0.1'
DB_PORT = '5432'
DB_USER = 'ftsender'
#DB_PASS = 'ivujfakCiph9cyGhocfonn7'
DB_PASS = 'Freetech123'
DB_BASE = 'ftsender'

DB_HOST_gammu = '127.0.0.1'
DB_PORT_gammu = '5432'
DB_USER_gammu = 'smsd'
DB_PASS_gammu = 'smsd'
DB_BASE_gammu = 'smsd'

# Aqui colocar las rutas de los archivos de config de cada modem*/
MODEMS = ['/etc/gammu-smsdrc', '/etc/gammu-smsdrc1', '/etc/gammu-smsdrc2',
		  '/etc/gammu-smsdrc3', '/etc/gammu-smsdrc4', '/etc/gammu-smsdrc5',
		  '/etc/gammu-smsdrc6', '/etc/gammu-smsdrc7', '/etc/gammu-smsdrc8',
		  '/etc/gammu-smsdrc9']

# Aqui colocar el nombre de los pids correspondientes a cada modem en
# correspondencia con la lista MODEMS anterior */
PIDS = ['/var/run/gammu-smsd.pid', '/var/run/gammu-smsd1.pid',
		'/var/run/gammu-smsd2.pid', '/var/run/gammu-smsd3.pid',
		'/var/run/gammu-smsd4.pid', '/var/run/gammu-smsd5.pid',
		'/var/run/gammu-smsd6.pid', '/var/run/gammu-smsd7.pid',
		'/var/run/gammu-smsd8.pid', '/var/run/gammu-smsd9.pid',]

# NODO_IP: sirve para validar que el demonio esta corriendo sobre la ip que
# le corresponde
NODO_IP = '172.20.2.249'









#/* LOS SIGUIENTES PARAMETROS NO DEBEN SER MODIFICADOS */
NOMBRE_DEMONIO = 'sms'

import os,sys
pathname, scriptname = os.path.split(sys.argv[0])
RUTA = os.path.abspath(pathname)+"/"
os.chdir(RUTA[:-1])

import commands
def crearsinoexiste(archivo):
	commands.getoutput("ls -lh "+archivo+" | touch "+archivo+"")
