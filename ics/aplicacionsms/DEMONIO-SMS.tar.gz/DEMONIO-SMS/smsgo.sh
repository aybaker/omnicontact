#/bin/bash
#arg1: mensaje
#arg2: PhoneID
#arg3: destino
echo $1 | /opt/gammu/gammu-1.34.0/build/gammu/gammu -s $2 sendsms TEXT $3