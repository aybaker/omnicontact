<?php
header("Content-type: application/x-msdownload");
header("Content-Disposition: attachment; filename=exportado.csv");
header("Pragma: no-cache");
header("Expires: 0");
echo "\n";

	$sql_exportar = $_POST['sql_exportar'];
	$sql_exportar = str_replace ( "{}" , "'" , $sql_exportar );

	include("../constantes.php");
	require_once("../lib/class.DataBase.php");
	#echo $_POST['sql_exportar']."<br>";
	$db = DataBase::getInstance();
	$db->setQuery( $sql_exportar );
	
	
	$columnas = $db->load_resource('array');
	$totalCol = $db->get_totalCol();
	
	$cvs="";
	//*** TITULO DE LAS COLUMNAS ***
	$array_titulos = $db->load_nombres_col();
	foreach($array_titulos as $titulon)   { $cvs .= $titulon.";"; }
	$cvs.="\n";
	
	//*** CAMPOS DE LA TABLA ***
	foreach($columnas as $columna)
	{
		for( $i=0; $i<$totalCol; $i++ )   { $cvs .= $columna[$i].";"; }
		$cvs.="\n";
	}
	
	echo $cvs;	

?>