<?php

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', true, true);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Daniel Oberti');
$pdf->SetTitle('Reporte Comercial DESOL');
$pdf->SetSubject('TCPDF chan');
$pdf->SetKeywords('TCPDF, PDF, ejemplo, test, guide');


	include("../constantes.php");
	require_once("../lib/class.DataBase.php");
	//echo $_POST['sql_exportar']."\n";
	$db = DataBase::getInstance();
	$db->setQuery( $_POST['sql_exportar'] );
	
	$columnas = $db->load_resource('array');
	$totalCol = $db->get_totalCol();
	
	$html_tabla = "<table style='width:100%;' align='left' cellspacing='1' >";
	$html_tabla .= "<tr>";

	//*** TITULO DE LAS COLUMNAS ***
	$array_titulos = $db->load_nombres_col();
	foreach($array_titulos as $i => $titulon)
	{
		$array_titulos[$i] = str_replace(";", "|", $array_titulos[$i]);
		$array_titulos[$i] = str_replace('\n', "", $array_titulos[$i]);
		$array_titulos[$i] = str_replace("\n", "", $array_titulos[$i]);
		$array_titulos[$i] = str_replace('<br />', "", $array_titulos[$i]);
		$array_titulos[$i] = str_replace("<br />", "", $array_titulos[$i]);
		$patron = "^(\r\n)+|^(\n)+|^(\r)+|^(\n\r)+";
		$array_titulos[$i] = eregi_replace($patron, ' ', $array_titulos[$i]);
		$array_titulos[$i] = str_replace(chr(10), " ", $array_titulos[$i]); //remove carriage returns
		$array_titulos[$i] = str_replace(chr(13), " ", $array_titulos[$i]); //remove carriage returns	
		
		IF( $array_titulos[$i]=='custom2' ) {$array_titulos[$i]='Cliente';}
		ELSE IF( $array_titulos[$i]=='subject' ) {$array_titulos[$i]='Descripcion';}
		ELSE IF( $array_titulos[$i]=='c.name' ) {$array_titulos[$i]='Categoria';}
		ELSE IF( $array_titulos[$i]=='u.name' ) {$array_titulos[$i]='Responsable';}
		
		$html_tabla .= "<th id='".str_replace("'", "-#-", $titulon)."' onclick='cambiar(this.id);' > $TITULO_MOSTRAR </th>";
		
	}	
	$html_tabla .= "</tr>";
	
	//*** CAMPOS DE LA TABLA ***
	foreach($columnas as $columna)
	{			
		for( $i=0; $i<$totalCol; $i++ )   
		{
			$columna[$i] = str_replace(";", "|", $columna[$i]);
			$columna[$i] = str_replace('\n', "", $columna[$i]);
			$columna[$i] = str_replace("\n", "", $columna[$i]);
			$columna[$i] = str_replace('<br />', "", $columna[$i]);
			$columna[$i] = str_replace("<br />", "", $columna[$i]);
			$patron = "^(\r\n)+|^(\n)+|^(\r)+|^(\n\r)+";
			$columna[$i] = eregi_replace($patron, ' ', $columna[$i]);
			$columna[$i] = str_replace(chr(10), " ", $columna[$i]); //remove carriage returns
			$columna[$i] = str_replace(chr(13), " ", $columna[$i]); //remove carriage returns
		
			$cvs .= $columna[$i].",";
			if( $i==0 )
			{
				$html .= "<TR>";
				$html .= "<TD style='height:8px;' class='rightAlign'>".$valor_col."</TD>";
			}
			else
			{
				$html .= "<TD style='background-color: white; height:8px;' class='rightAlign'><b>".$valor_col."</b></TD>";
			}
		}
		$html .= "</TR>";
	}
	$html .= "</table>";
	

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 065', PDF_HEADER_STRING);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set default font subsetting mode
$pdf->setFontSubsetting(true);

// Set font
$pdf->SetFont('helvetica', '', 8, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->AddPage();

// Set some content to print
$html = <<<EOD
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
}
-->
</style></head>

<body>
<!--<p><img src="header-nacion.jpg" width="1000" height="89" /></p>-->

<? echo $html_tabla; ?>
<p>El presente se suscribe mediante firma facsimilar conforme lo previsto en el punto 7.9 del Reglamento General de la Actividad Aseguradora.</p>
<!--<p><img src="membrete.jpg" width="1000" height="56" /></p>-->
</body>
</html>


EOD;

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);

// ---------------------------------------------------------

// Close and output PDF document
// This method has several options, check the source code documentation for more information.
$pdf->Output('reporte.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
