<?php
header( 'Content-Type: text/html;charset=iso-8859-1' );
session_start();

include("../constantes.php");
include("../lib/funciones.php");

if( isset($_GET['debug']) ) 
	$_SESSION['DEBUG'] = $_GET['debug'];
else if( !isset($_SESSION['DEBUG']) ) 
	$_SESSION['DEBUG'] = 0;

	
$__VARIABLE____ID_PAGINA = "SMS";
$__VARIABLE____TITULO_PAGINA = "Reporte SMS enviados";
$__VARIABLE____TITULO_LOCAL = "Reporte SMS enviados";
$__VARIABLE____PAGINACION_CANT_REG = 50;
$__VARIABLE____TABLA_ALTO = "70%";
$__VARIABLE____LINK_SEL_COLOR = "white";
$__VARIABLE____bordercolor = "#bbbbcf";
$__VARIABLE____background_menu = "#31B404";
$__VARIABLE____background_menu2 = "#2E2E2E";
$__VARIABLE____color_titulo = "white";

##############################################################
#                    opciones del MENU                       #
##############################################################
if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar']) ) {$_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar'] = 0;}
if( isset($_POST['Reset']) ) {$_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar'] = 0;}


if( isset($_GET['bd_contacto_id']) )
{
	$_SESSION[$__VARIABLE____ID_PAGINA.'bd_contacto_id'] = $_GET['bd_contacto_id'];
}

$__VARIABLE____TITULO_LOCAL = $__VARIABLE____TITULO_LOCAL." / campa�a n� ".$_SESSION[$__VARIABLE____ID_PAGINA.'bd_contacto_id'];

##############################################################
  	
	require_once("../lib/class.DataBase.php");
	$db = DataBase::getInstance();
		
	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	if( !isset($_FILTRO_CONSULTA) ) { $_FILTRO_CONSULTA = ""; }
	if( !isset($_FILTRO_HAVING) ) { $_FILTRO_HAVING = ""; }

	$CAMPOS_HAVING = array('Horas', 'Presupuesto', 'Estado', 'Categoria', 'Agente' );
  
	$_FILTRO_HAVING = "";
	$_FILTRO_HAVING_2 = "";
 
	if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc']) ) { $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc'] = ""; }
	if( isset($_POST['relacion_busc']) ) { $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc'] = $_POST['relacion_busc'];}
	
	if( !isset($_FILTRO_CONSULTA) ) { $_FILTRO_CONSULTA = ""; }
	if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']) || isset($_POST['Reset']) )   { $_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc'] = ""; $_SESSION[$__VARIABLE____ID_PAGINA.'filtro'] = ""; $_FILTRO_CONSULTA = "";}
	else
	{

		if( isset($_POST['Filtrar']) )
		{
			$_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar'] = 1;
			$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc'] = $_POST['columna']; 
			$_SESSION[$__VARIABLE____ID_PAGINA.'filtro'] = $_POST['filtro'];
		}
		
		if(  $_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']!=""  &&  $_SESSION[$__VARIABLE____ID_PAGINA.'filtro']!=""  )
		{
			if (in_array($_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc'], $CAMPOS_HAVING))
			{
				switch( $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc'] )
				{
					case 'like': $_FILTRO_HAVING =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." like '%".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."%' "; break;
					case '>': $_FILTRO_HAVING =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." > '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '<': $_FILTRO_HAVING =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." < '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '=': $_FILTRO_HAVING =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." = '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '<>': $_FILTRO_HAVING =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." <> '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					default: echo "Error, la relaci�n de busqueda es inexistente<br>";
				}
			} 
			else 
			{
				switch( $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc'] )
				{
					case 'like': $_FILTRO_CONSULTA =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." like '%".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."%' "; break;
					case '>': $_FILTRO_CONSULTA =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." > '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '<': $_FILTRO_CONSULTA =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." < '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '=': $_FILTRO_CONSULTA =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." = '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					case '<>': $_FILTRO_CONSULTA =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc']." <> '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."' "; break;
					default: echo "Error, la relaci�n de busqueda es inexistente<br>";
				}
			} 


		}
	}
	
	if( isset($_GET['id']) ) 
	{
		$_FILTRO_CONSULTA .= " AND A.id=".$_GET['id']." ";
	}
	

	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2']) ) { $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2'] = ""; }
	if( isset($_POST['relacion_busc_2']) ) { $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2'] = $_POST['relacion_busc_2'];}
	
	if( !isset($_FILTRO_CONSULTA_2) ) { $_FILTRO_CONSULTA_2 = ""; }
	if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']) || isset($_POST['Reset']) )   
	{ 
		$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2'] = ""; 
		$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2'] = ""; 
		$_FILTRO_CONSULTA_2 = "";
	}
	else
	{
	
	
		if( isset($_POST['Filtrar']) )
		{ 
			$_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar'] = 1;
			$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2'] = $_POST['columna_2']; 
			$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2'] = $_POST['filtro_2']; 
		}
		
		if(  $_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']!=""  &&  $_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']!=""  )
		{
			if (in_array($_SESSION['columna_busc_2'], $CAMPOS_HAVING))
			{
				switch( $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2'] )
				{
					case 'like': $_FILTRO_HAVING_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." like '%".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."%' "; break;
					case '>': $_FILTRO_HAVING_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." > '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '<': $_FILTRO_HAVING_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." < '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '=': $_FILTRO_HAVING_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." = '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '<>': $_FILTRO_HAVING_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." <> '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					default: echo "Error, la relaci�n de busqueda es inexistente<br>";
				}
			}
			else
			{
				switch( $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2'] )
				{
					case 'like': $_FILTRO_CONSULTA_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." like '%".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."%' "; break;
					case '>': $_FILTRO_CONSULTA_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." > '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '<': $_FILTRO_CONSULTA_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." < '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '=': $_FILTRO_CONSULTA_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." = '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					case '<>': $_FILTRO_CONSULTA_2 =  " AND ".$_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2']." <> '".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."' "; break;
					default: echo "Error, la relaci�n de busqueda es inexistente<br>";
				}
			} 
			

		}
	}
	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
	
	$titulo = " sms_enviado ";
	$class_titulo = "SortDown";
	$ordenar =  " DESC ";
	if(  isset($_GET['orden'])  )
	{ 
		$class_titulo = $_GET['orden'];
		$titulo = $_GET['titulo_orden'];
		if( $class_titulo ==  "SortUp") { $ordenar =  " ASC "; }
		if( $class_titulo ==  "SortDown") { $ordenar =  " DESC "; }
	}

	if( !isset($_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini']) )
	{
		$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini'] = date('Y-m-d');
		$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_fin'] = date('Y-m-d');
	} 
	else if( isset($_POST['fecha_ini']) )
	{
		$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini'] = $_POST['fecha_ini'];
		$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_fin'] = $_POST['fecha_fin'];
	}
	


	//=======================================================
	$_limit = 22;  // max cant de reg por pagina 	
	$pag = 1;
	if( isset($_GET["pag"]) )   { $pag = (int) $_GET["pag"]; }
	if ($pag < 1)  { $pag = 1; } 
	$offset = ($pag-1) * $_limit; 			
?>
<html>
<head>
	<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">

	<title><?php echo $__VARIABLE____TITULO_PAGINA; ?></title>
	<style type="text/css">@import "../css/default.css";</style>
		
	<script type="text/javascript">
	var ID_FILA = new Array();
	
	function cambiar(id)
	{	
		if( document.getElementById(id).className != 'SortDown' )
		{
			while(id.indexOf('-#-') >= 0) {alert(id); id = id.replace('-#-',"'");}
			<?php echo "location.href='?&orden=SortDown&titulo_orden='+id+'&pag=$pag';";?> 
		}
		else
		{
			while(id.indexOf('-#-') >= 0) {alert(id); id = id.replace('-#-',"'");}
			<?php echo "location.href='?&orden=SortUp&titulo_orden='+id+'&pag=$pag';";?> 
		}
	}

	function selecFila(id)
	{
		ID_FILA.push( id );
		//ID_FILA.forEach(function(item) { alert('elemento '+item) });
	}

	
	function deselecFila(id)
	{
		var pos;
		for( pos=0; pos<ID_FILA.length; pos++ )
		{
			if(ID_FILA[pos] == id)  break;
		}
		ID_FILA.splice(pos,1);
		//ID_FILA.forEach(function(item) { alert('elemento '+item) });
	}
	</script>
	
	<!-- librerias para el datepicker desplegable -->
	<script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
	<link type="text/css" href="css/ui-lightness/jquery-ui-1.8.18.custom.css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery-ui-1.8.18.custom.min.js"></script>
	
	<script type="text/javascript">
		$(function() {
		  $("#fecha_ini").datepicker({
			dateFormat: 'yy-mm-dd', // formato de fecha que se usa en Espa�a
			dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi�rcoles', 'Jueves', 'Viernes', 'Sabado'], // d�as de la semana
			dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'], // d�as de la semana (versi�n super-corta)
			dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'], // d�as de la semana (versi�n corta)
			firstDay: 1, // primer d�a de la semana (Lunes)
			maxDate: new Date(), // fecha m�xima
			minDate: '-2y',
			monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'], // meses
			monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'], // meses
			navigationAsDateFormat: true,
			});
			
		  $("#fecha_fin").datepicker({
			dateFormat: 'yy-mm-dd', // formato de fecha que se usa en Espa�a
			dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi�rcoles', 'Jueves', 'Viernes', 'Sabado'], // d�as de la semana
			dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'], // d�as de la semana (versi�n super-corta)
			dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'], // d�as de la semana (versi�n corta)
			firstDay: 1, // primer d�a de la semana (Lunes)
			maxDate: new Date(), // fecha m�xima
			minDate: '-2y',
			monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'], // meses
			monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'], // meses
			navigationAsDateFormat: true,
			});			
		});
	  </script>	
	<!-- librerias para el datepicker desplegable -->
	
  <script type="text/javascript">
  function popup_dan(t)
  {
	window.open(t.href,t.target,"toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=420,height=400px,left=430px,top=23");
  }
  </script>	
</head>



<body onload="document.forms['form_filtro'].filtro.focus();" <?php echo "bgcolor='$color_body'"; ?> >
	<center>
	<?php 
	echo "<div style='position:absolute; top:0px;left:0px;width:105%; height:50px; background-color:$__VARIABLE____background_menu2; color:white;'> ";
	#echo "<b>$__VARIABLE____TITULO_LOCAL</b>"; 
	echo "</div>";
	?>
	</center>

<br><br>
	
<?php echo "<h2 style='margin:20px;margin-left:50px;margin-right:50px;background-color:$__VARIABLE____background_menu;color:$__VARIABLE____color_titulo;padding:5px;'>$__VARIABLE____TITULO_LOCAL</h2>"; ?>

<a href="../REPORTE_SMS" >Volver</a>
<a style="margin-left:40px;" href=''><img style='width:30px;' src='../css/imgs/refresh.png'/></a>
	
<?php
	$_limit_fecha = 360; //maximo barrido de fecha permitida

$var_temp_dif_dias = dif_dias( $_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini'], $_SESSION[$__VARIABLE____ID_PAGINA.'fecha_fin'] ) + 1;


if( $var_temp_dif_dias > $_limit_fecha ) 
{
	echo " (Maximo $_limit_fecha dias ) <b>Filtro1 � Filtro2</b>=20dias  |  <b>Filtro1 + Filtro2</b>=31dias";
	$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini'] = date('Y-m-d');
	$_SESSION[$__VARIABLE____ID_PAGINA.'fecha_fin'] = date('Y-m-d');
}


	//================= AQUI PONER LA CONSULTA ================	
	
	#$consulta_pg = "SELECT A.id, A.nombre, A.fecha_inicio, A.fecha_fin, A.bd_contacto_id, A.estado 
	#		FROM fts_web_campanasms A
	#		WHERE 1=1 $_FILTRO_CONSULTA $_FILTRO_CONSULTA_2  order by $titulo $ordenar LIMIT $_limit offset $offset; ";
	
	$consulta_pg = "SELECT id, sms_enviado_fecha, destino, case sms_enviado when -1 then 'Error en el envio' when 0 then 'no procesado' when 1 then 'enviado OK' when -2 then 'no hay modem disponible' end as estado_envio, datos from fts_web_contacto_".$_SESSION[$__VARIABLE____ID_PAGINA.'bd_contacto_id']." 
				WHERE 1=1 $_FILTRO_CONSULTA $_FILTRO_CONSULTA_2  order by $titulo $ordenar LIMIT $_limit offset $offset; ";
	$var_temp = explode("LIMIT", $consulta_pg);
	$consulta_pg_exportar = $var_temp[0];
	#echo "sql_exportar: $consulta_pg_exportar<br>";
	$consulta_pg_exportar = str_replace ( "'" , "{}" , $consulta_pg_exportar );
	#echo "sql_exportar: $consulta_pg_exportar<br>";
	
	#echo "<b style='position:absolute; top:200; z-index:999999; background-color: yellow;'>sql=$consulta_pg</b>";
	$db->setQuery($consulta_pg);

	$columnas = $db->load_resource('array');
	$totalCol = $db->get_totalCol();
	$totalRows = $db->get_totalFil();
	// Total de registros sin limit 
	$total = $db->get_found_rows();
	$listado_titulos = $db->load_nombres_col();
	//=======================================================
	
	
	#CORRECCION DE TITULOS
	$listado_titulos_mostrar = array();
	foreach($listado_titulos as $i => $titulon)
	{
		$TITULO_MOSTRAR = $titulon;
		IF( $TITULO_MOSTRAR=='sms_enviado_fecha' ) {$TITULO_MOSTRAR='Fecha de env�o';}
		ELSE IF( $TITULO_MOSTRAR=='destino' ) {$TITULO_MOSTRAR='Destino';}
		ELSE IF( $TITULO_MOSTRAR=='sms_enviado' ) {$TITULO_MOSTRAR='Enviado';}
		ELSE IF( $TITULO_MOSTRAR=='datos' ) {$TITULO_MOSTRAR='Datos';}
		ELSE IF( $TITULO_MOSTRAR=='sec_to_time(billsec)' ) {$TITULO_MOSTRAR='tiempo exacto';}
		ELSE IF( $TITULO_MOSTRAR=='CEIL(billsec/60)' ) {$TITULO_MOSTRAR='minutos';}
		ELSE IF( stripos($TITULO_MOSTRAR,"userfield")!== FALSE ) {$TITULO_MOSTRAR='grabacion';}
		
		$listado_titulos_mostrar[$i] = $TITULO_MOSTRAR;
	}	
	?>

	
	<?php 
	##echo "<div style='position:absolute; height:434px; width:85px; left:0px; top:134px; text-align:center; border:solid 1px; border-left:none; border-color:$__VARIABLE____bordercolor; background-color:$__VARIABLE____background_menu2;' >";  
	##BUSCAR##echo "<a onclick='javascript:document.getElementById(\"form_filtro\").style.display=\"block\";'><p style=\"cursor:pointer; height:27px; line-height:27px;  color:#444444; background:url('../fondo_boton.png') repeat-x; font: 13px arial,sans-serif;\" onmouseover='this.style.color=\"black\";' onmouseout='this.style.color=\"#444444\";'><b>Buscar</b></p></a>";
	##CREAR## echo "<a href='crear_editar.php?orden=$class_titulo&titulo_orden=$titulo&pag=$pag' target='_self' onClick=\"window.open(this.href, this.target, 'width=1024,height=550'); return false;\" ><p style=\"cursor:pointer; height:27px; line-height:27px;  color:#444444; background:url('../fondo_boton.png') repeat-x; font: 13px arial,sans-serif;\" onmouseover='this.style.color=\"black\";' onmouseout='this.style.color=\"#444444\";' ><b>Crear</b></p></a>";
	##ELIMINAR## echo "<a href='index.php?opcion=delete&orden=$class_titulo&titulo_orden=$titulo&pag=$pag' target='_self' onClick=\"var muchos_id=''; if(ID_FILA=='') {alert('no selecciono ningun registro'); return false;} if( !confirm('Realmente desea ELIMINAR?') ){return false;} if(ID_FILA){ for(var i=0; i<ID_FILA.length;i++) { if(i!=0){muchos_id = muchos_id+'-'; } muchos_id = muchos_id+ID_FILA[i];} } this.href=this.href+'?&muchos_id='+muchos_id; window.open(this.href, this.target); return false;\" ><p style=\"cursor:pointer; height:27px; line-height:27px;  color:#444444; background:url('../fondo_boton.png') repeat-x; font: 13px arial,sans-serif;\" onmouseover='this.style.color=\"black\";' onmouseout='this.style.color=\"#444444\";' ><b>Eliminar</b></p></a>";
	##echo "</div>";
	?>
	
	
	<center>
	<?php
	$var_temp_display='none'; if ($_SESSION[$__VARIABLE____ID_PAGINA.'menu_filtrar'] == 1) {$var_temp_display='block';}
	?>	
	<form name='form_filtro' id='form_filtro' <?php echo "style='position:relative; display:$var_temp_display; text-align:left; margin-left:5px; width:90%; margin:4px; border:solid; border-color:$__VARIABLE____bordercolor; background-image: url(imgs/header.png); font-size:13px; z-index:0;'"; ?> method='post' action='index.php' >

		<input style='margin-left:40px;' type="text" size='9' id="fecha_ini" name="fecha_ini" value='<?php echo $_SESSION[$__VARIABLE____ID_PAGINA.'fecha_ini'];?>' style="z-index:1;" />&nbsp;
		<b>hasta</b> <input type="text" size='9' id="fecha_fin" name="fecha_fin" value='<?php echo $_SESSION[$__VARIABLE____ID_PAGINA.'fecha_fin'];?>' style="z-index:1;" />
		&nbsp;<b style='color:aCCCCC; font-size=18px;'>||</b>&nbsp;
		
		<b>Filtro1</b>
		<select name='columna' style="z-index:1;" >
		<?php		
		foreach($listado_titulos_mostrar as $i => $titulon)
		{
			$TITULO_MOSTRAR = $titulon;
			$selected = "";
			if( $listado_titulos[$i] == $_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc'] ) $selected = " selected='selected' ";
			if( $TITULO_MOSTRAR == 'dest_nombre' && $_SESSION[$__VARIABLE____ID_PAGINA.'filtro'] == "" ) $selected = " selected='selected' ";
			if( $i!=0 && $TITULO_MOSTRAR!='fecha_llamada') echo  "<option value='".str_replace("'", "-#-", $listado_titulos[$i])."' $selected>$TITULO_MOSTRAR</option>";
		}
		?>
		</select>
		
		<select name='relacion_busc' style="z-index:1;" >
		<?php
		
		#DEFINICION DE RELACIONES DE BUSQUEDA PARA LOS FILTROS
		$listado_relacion_busc_texto = array( "igual a", "contiene", "menor que", "mayor que", "distinto" );
		$listado_relacion_busc_valor = array( "=", "like", "<", ">", "<>" );
		
		
		foreach($listado_relacion_busc_valor as $key => $valor)
		{
			$selected = "";
			if( $valor == $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc'] ){ $selected = "selected='selected'"; }
			echo "<option value='$valor' $selected >".$listado_relacion_busc_texto[$key]."</option> ";
		}
		?>
		</select>
		
		<input type="text" size='10' id="keyword" name="filtro"  <?php echo "value='".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro']."'"; ?> onKeyPress=" if(this.value.length>0) {this.style.color='red';} else {this.style.color='black';} " onFocus=" if(this.value.length>0) {this.style.color='red';} else {this.style.color='black';} " />
		
		
		&nbsp; &nbsp;<b style='color:aCCCCC; font-size=13px;'>||</b>&nbsp; &nbsp;
		
		
		<b>Filtro2</b>
		<select name='columna_2' style="z-index:1;" >
		<?php
		foreach($listado_titulos_mostrar as $i => $titulon)
		{
			$TITULO_MOSTRAR = $titulon;
			$selected = "";
			if( $listado_titulos[$i] == $_SESSION[$__VARIABLE____ID_PAGINA.'columna_busc_2'] ) $selected = " selected='selected' ";
			if( $TITULO_MOSTRAR == 'dest_obs' && $_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2'] == "" ) $selected = " selected='selected' ";
			if( $i!=0 && $TITULO_MOSTRAR!='fecha_llamada') echo  "<option value='".str_replace("'", "-#-", $listado_titulos[$i])."' $selected>$TITULO_MOSTRAR</option>";
		}
		?>
		</select>
		
		<select name='relacion_busc_2' style="z-index:1;" >
		<?php
		foreach($listado_relacion_busc_valor as $key => $valor)
		{
			$selected = "";
			if( $valor == $_SESSION[$__VARIABLE____ID_PAGINA.'relacion_busc_2'] ){ $selected = "selected='selected'"; }
			echo "<option value='$valor' $selected >".$listado_relacion_busc_texto[$key]."</option> ";
		}
		?>
		</select>
		
		<input type="text" size='10' id="keyword_2" name="filtro_2"  <?php echo "value='".$_SESSION[$__VARIABLE____ID_PAGINA.'filtro_2']."'"; ?> onKeyPress=" if(this.value.length>0) {this.style.color='red';} else {this.style.color='black';} " onFocus=" if(this.value.length>0) {this.style.color='red';} else {this.style.color='black';} " />
		
		&nbsp;&nbsp;<b style='color:aCCCCC; font-size=13px;'>||</b>&nbsp;&nbsp;
		
		<input type="submit" style="width:50px;" name='Filtrar' value="Busca" />
		<input type="submit" style="width:50px;" name='Reset' value="Reset" />
		
	</form>
	</center>

	 <center>	
	<div  <?php echo "style='width:90%; height:$__VARIABLE____TABLA_ALTO; overflow-y:auto; background-color:#fdfdfd; text-align:center;'"; ?>  >

	<table style='width:100%;text-align:left;' cellspacing='1' id="styling-cutom-highlighting" >
	  <thead>
		<tr>
				<?php
				//*** TITULO DE LAS COLUMNAS ***
				foreach($listado_titulos_mostrar as $i => $titulon)
				{
					$TITULO_MOSTRAR = $titulon;
					$class_th = 'header';
					if( $titulo == $listado_titulos[$i] ) $class_th = $class_titulo;
					/*if( $i!=0 )*/ echo  "<th class='$class_th' id='".str_replace("'", "-#-", $listado_titulos[$i])."' onclick='cambiar(this.id);' > $TITULO_MOSTRAR </th>";
				}		    
				?>   
		</tr>
	  </thead>
	  <tbody style='overflow-y:auto;'>   
	  
	<?php
	//*** CAMPOS DE LA TABLA ***
	foreach($columnas as $columna)
	{
		for( $i=0; $i<$totalCol; $i++ )
		{

			$valor_col = $columna[$i];
			$var_temp_color_columna = "";
			 if( $listado_titulos[$i] == 'precio' ) {$valor_col = '$'.$valor_col;}
			 if( $listado_titulos[$i] == 'tar_costo' ) {$valor_col = '$'.$valor_col; $var_temp_color_columna = " style='background-color: white;height:8px; color:#084B8A; font-weight:bold;' ";}
			 
			 if( $i==0 )
			 {
				$var_temp_pag_editar = "crear_editar.php?orden=$class_titulo&titulo_orden=$titulo&pag=$pag&INDICE=$valor_col";
				echo "<TR id='".str_replace("'", "-#-", $valor_col)."'  onmouseover=\"if( this.className!='selec' )this.className='encima'\"; onmouseout=\"if( this.className!='selec' )this.className='fuera';\"; onClick=\"javascript: if( this.className!='selec' ) {   this.className='selec';  selecFila(this.id); } else {  this.className='fuera'; deselecFila(this.id); }\">";
				echo "<TD style='height:8px;' class='rightAlign'>".$valor_col."</TD>";
			 }
			 else if($listado_titulos[$i]=='CEIL(A.billsec/60)' && $valor_col!="" && $valor_col!=" ")
			 {

				$var_temp_time = $valor_col;
				
				if( $var_temp_time>0   ) {$color = '#084B8A';} 
				if( $var_temp_time>(2)  ) {$color = '#0B610B';} 
				if( $var_temp_time>(5)  ) {$color = '#04B431';} 
				if( $var_temp_time>(10)  ) {$color = 'black';} 
				if( $var_temp_time>(15)  ) {$color = '#FF8000';} 
				if( $var_temp_time>(20) ) {$color = '#FF0000';} 
				if( $var_temp_time>(30) )   {$color = '#FF0080';} 
				
				echo "<TD style='background-color: white; height:8px;' class='rightAlign'><b style='color:$color;'>".$valor_col."</b></TD>";
			 }
			 else {echo "<TD $var_temp_color_columna >".$valor_col."</TD>";}
		}
		echo "</TR>";
	}			 
	?> 			
	  </tbody>
	</table>

	</div>
	
	

	
  		<?php
echo "<table style='width:90%;height:20px;border:0;font-size:11px;text-align:left; background-color:$__VARIABLE____background_menu2;' >";

		//============= START LINKS DE PAGINACION ==============
		$totalPag = ceil($total/$_limit);
		$links = array(); 
		$nav_pag1 = "";
		$nav_pag2 = "";
		$nav_pag3 = "<b style='color:$__VARIABLE____LINK_SEL_COLOR;' >$pag</b>/$totalPag";
		
		IF( ($pag-3) > 1 ) $nav_pag1 .= "<a href=\"?&pag=".($pag-1-3)."&orden=$class_titulo&titulo_orden=$titulo\" >&nbsp;<b style='font-size:12px;'>&laquo;&laquo;&laquo;</b>&nbsp;&nbsp;</a>";
		IF( $pag > 1 ) $nav_pag1 .= "<a href=\"?&pag=".($pag-1)."&orden=$class_titulo&titulo_orden=$titulo\" >&nbsp;<b style='font-size:12px;'>&laquo;</b>&nbsp;&nbsp;</a>";
		
		$var_temp1 = $pag-5;
		if($var_temp1<0) {$var_temp1=1;}
		
		$var_temp2 = $pag+5;
		if($var_temp2>$totalPag) {$var_temp2=$totalPag;}
		
		for( $i=$var_temp1; $i<=$var_temp2 ; $i++) 
		{
			$color = "style='font-size:12px;'";
			IF( $pag == $i ) { $color = "style='color:$__VARIABLE____LINK_SEL_COLOR;font-size:12px;'"; }
			IF( $i%1==0 ) $links[] = "<a href=\"?&pag=$i&orden=$class_titulo&titulo_orden=$titulo\" $color  >$i</a>";  
		}
		
		IF( $pag < $totalPag ) $nav_pag2 = "<a href=\"?&pag=".($pag+1)."&orden=$class_titulo&titulo_orden=$titulo\" >&nbsp;&nbsp;<b style='font-size:12px;'>&raquo;</b>&nbsp;</a>";
		IF( ($pag+3) < $totalPag ) $nav_pag2 .= "<a href=\"?&pag=".($pag+1+3)."&orden=$class_titulo&titulo_orden=$titulo\" >&nbsp;&nbsp;<b style='font-size:12px;'>&raquo;&raquo;&raquo;</b>&nbsp;</a>";
	
	
			echo "<TR>";
			echo "<th style='background-color:$__VARIABLE____background_menu2;' colspan='".($totalCol-1-1)."' >";
			echo "$nav_pag1"; echo implode(" ", $links); echo "$nav_pag2"; 
			echo "</th>";
			echo "<th style='background-color:$__VARIABLE____background_menu2; color:white;' >";
			echo $nav_pag3;
			echo "</th>";
			echo "<th style='background-color:$__VARIABLE____background_menu2; color:white;'>";
			echo "  Cantidad: $total";
			echo "</th>";
			echo "<th style='background-color:$__VARIABLE____background_menu2; color:white;'>";
			?>
			<form method='POST' action='exportar_cvs.php' style='width:50px; margin:0px;' >
				<input type='submit' name='exportar' value='exportar' alt="exportar a Excel"  >																
				<?php echo "	<INPUT type='hidden' name='sql_exportar' value='".$consulta_pg_exportar."' >"; ?>
			</form>			
			<?php
			echo "</th>";
			
			echo "</TR>"; 
		?>	
</table>


<center>


<?php
	$db->freeResults();
		 
	//para marcar el registro que se estaba viendo al regresar al datagrid
	if( isset($_GET['_indice']) ) {$_indice=$_GET['_indice'];}
	if( isset($_POST['id']) ) {echo "<script type='text/javascript'>var aux = document.getElementById('".$_POST['id']."'); aux.className='selec'; selecFila(".$_POST['id'].")</script>";}
	if( isset($_indice) ) {echo "<script type='text/javascript'>var aux = document.getElementById('".$_indice."'); aux.className='selec'; selecFila(".$_indice.")</script>";}
	if( isset($id_campania) ) {echo "<script type='text/javascript'>var aux = document.getElementById('".$id_campania."'); aux.className='selec'; selecFila(".$id_campania.")</script>";}
?>

</center>

</body>
</html>
