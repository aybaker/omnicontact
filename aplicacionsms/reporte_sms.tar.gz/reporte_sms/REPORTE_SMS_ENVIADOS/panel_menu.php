<?php

	include_once("../lib/Excel/reader.php");
	
	IF( ISSET($_GET['opcion']) && $_GET['opcion']=="delete" )
	{
		if( isset($_GET['muchos_id']) )
		{
			$muchos_id = $_GET['muchos_id']; 
			$_array_id = split( '-', $muchos_id );
			$INDICE	 = $_array_id[0];
			for($i=0; $i<COUNT($_array_id); $i++)
			{	
				$sqlaux = "DELETE FROM asterisk.extensions_table WHERE comentario='camp:".$_array_id[$i]."'";
				#echo $sqlaux;
				$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );
				
				$myquery6 = " DELETE FROM asterisk.queue_table WHERE name='".$_array_id[$i]."' ";
				#echo "myquery6=$myquery6<br>";
				$result6 = mysql_query( $myquery6 )or die( $myquery6."<br>".mysql_error() );

				#print "ELIMINACI�N EXITOSA!";
			}			
		}
	}
	
	
	
	
	
	
	
	
	IF(  ISSET($_POST['opcion']) && ($_POST['opcion']=="Crear" || $_POST['opcion']=="Guardar") )
	{	
				
		if( $_POST['opcion']=="Crear" )
		{
			$i = 0;
			$SQL_nombres = "";
			$SQL_valores = "";
			#$fecha = date("Y-m-d H:i:s");
			foreach($_POST as $nombre_campo => $valor)
			{
				$valor = sanear_string($valor);
				$asignacion = "\$" . $nombre_campo . "='" . $valor . "';";
				#echo "$asignacion<br>";
				eval($asignacion); 
			
				if(  $nombre_campo!="opcion" && $nombre_campo!="id"  )
				{
					if($i==0) 
					{
						$SQL_nombres .= " `$nombre_campo` ";
						$SQL_valores .= " '$valor' ";
					} else {
						$SQL_nombres .= " ,`$nombre_campo` ";
						$SQL_valores .= " ,'$valor' ";
					}
					$i++;
				}
				
			}
			
			$SQL = " INSERT INTO asterisk.queue_table (  $SQL_nombres ) VALUES ( $SQL_valores ) ";
			#echo "$SQL<br>";
			$result = mysql_query( $SQL )or die( "Problemaso: <b>$SQL</b><br>".mysql_error() );	


			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',1,'NoOp','========= CAMPANIA_IN $name =========','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',2,'GotoIfTime','08:00-21:00,mon,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',3,'GotoIfTime','08:00-21:00,tue,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );				
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',4,'GotoIfTime','08:00-21:00,wed,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',5,'GotoIfTime','08:00-21:00,thu,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',6,'GotoIfTime','08:00-21:00,fri,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );					

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',7,'GotoIfTime','08:00-21:00,sat,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',8,'GotoIfTime','08:00-21:00,sun,*,*?10','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );		

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',9,'Hangup','','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',10,'set','calltime=".'${STRFTIME(${EPOCH},,%C%y%m%d%H%M%S)}'."','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',11,'set','grabacion=ENTRANTE_CAMP-$name".'_${calltime}FROM${CALLERID(num)}TO${EXTEN}.wav'."','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',12,'Mixmonitor','".'${grabacion}'."','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',13,'Set','CDR(userfield)=audio:".'${grabacion}'."','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	

			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',14,'Queue','$name','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );	
			
			$sqlaux = "INSERT INTO asterisk.extensions_table (context,exten,priority,app,appdata,comentario) VALUES ('Campanias','$myextension',15,'Hangup','','camp:$name'); ";
			$resultaux = mysql_query( $sqlaux )or die( $sqlaux."<br>".mysql_error() );					

		}
		else if( $_POST['opcion']=="Guardar" )
		{
		
			$INDICE = $_POST['id'];
			$i = 0;
			$SQL_nom_val = "";
			foreach($_POST as $nombre_campo => $valor)
			{	
				$valor = sanear_string($valor);
				$asignacion = "\$" . $nombre_campo . "='" . $valor . "';";
				eval($asignacion); 		
				if(  $nombre_campo!="opcion" && $nombre_campo!="id"  )
				{
					if( $i==0 ) {$SQL_nom_val .= " `$nombre_campo`='$valor' ";}
					else 		{$SQL_nom_val .= " ,`$nombre_campo`='$valor' ";}
					$i++;
				}
			}
			
			$SQL = " UPDATE asterisk.queue_table SET $SQL_nom_val WHERE name='$INDICE' ";
			#echo "$SQL<br>";
			$result = mysql_query( $SQL )or die( "Problema sql: <b>$SQL</b><br>".mysql_error() );	
			
		}
	}

 
?>








