<?php

require_once('../config/lang/eng.php');
require_once('../tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', true, true);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Daniel Oberti');
$pdf->SetTitle('TCPDF Ejemplo 1');
$pdf->SetSubject('TCPDF chan');
$pdf->SetKeywords('TCPDF, PDF, ejemplo, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 065', PDF_HEADER_STRING);

// set header and footer fonts
//$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set default font subsetting mode
$pdf->setFontSubsetting(true);

// Set font
$pdf->SetFont('helvetica', '', 8, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->AddPage();

// Set some content to print
$html = <<<EOD
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
}
-->
</style></head>

<body>
<p><img src="header-nacion.jpg" width="1000" height="89" /></p>
<table width="1000" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="155">Lugar y Fecha: </td>
    <td colspan="5">CAPITAL FEDERAL, a las 15:24:51 hs del 20/10/2011</td>
  </tr>
  <tr>
    <td>Vigencia: </td>
    <td colspan="5">desde el 20/10/2011 hasta el 20/04/2012</td>
  </tr>
  <tr>
    <td>N� Certificado:</td>
    <td width="201">0 - 1485889</td>
    <td width="51">Item:</td>
    <td width="81">6</td>
    <td width="81">Solicitud:</td>
    <td width="234">4 - 862434</td>
  </tr>
  <tr>
    <td>Asegurado:</td>
    <td colspan="5">LEONARDELLI MARIA FLORENCIA</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><img src="vehiculo.jpg" width="1000" height="37" /></p>
<table width="1000" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td width="143">Marca: </td>
    <td colspan="3">FIAT</td>
    <td width="145">Modelo:</td>
    <td width="293">PALIO ELD</td>
  </tr>
  <tr>
    <td>A�o:</td>
    <td>1998</td>
    <td>Suma asegurada:</td>
    <td>24.000,00</td>
    <td>Uso:</td>
    <td>PARTICULAR</td>
  </tr>
  <tr>
    <td>Tipo:</td>
    <td colspan="3">AUTOMOVIL ---------------</td>
    <td>Origen:</td>
    <td>Nacional</td>
  </tr>
  <tr>
    <td>Dominio:</td>
    <td colspan="3">BZS711</td>
    <td>Carrocer�a:</td>
    <td>5 PUERTAS</td>
  </tr>
  <tr>
    <td>Motor:</td>
    <td colspan="3">176A50005052148</td>
    <td>Chasis:</td>
    <td>BAP178378W4071904</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><img src="cobertura.jpg" width="1000" height="29" /></p>
<p>RESPONSABILIDAD CIVIL LIMITADA A PESOS 3.000.000,00.</p>
<p>&nbsp;</p>
<p><img src="texto.jpg" width="1000" height="29" /></p>
<p>NO POSEE<br />
  Esta Unidad cuenta con el servicio de Asistencia Mec�nica de SOS (0054) - 0800-333-3300 / (0054) -<br />
  11-4129-8100<br />
  Por cualquier consulta comun�quese con el centro de atenci�n al cliente 0800-888-9908 de Lunes a<br />
  Viernes de 9.00 a 18.00hs.<br />
  ADVERTENCIA AL ASEGURADO: El presente es un instrumento provisorio. Dentro de los QUINCE (15) DIAS<br />
  corridos, contados a partir de su fecha de emisi�n, deber� requerirse la entrega de la p�liza<br />
respectiva.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><img src="firma.jpg" width="1000" height="105" /></p>
<p>Acreedor Prendario:<br />
  Fecha Emisi�n: 20/10/11<br />
  Pedido por: BARBERO LUCIA<br />
  Productor 47864 - VIS BROKERS ASESORES DE SEGUROS S.A. <br />
</p>
<p>El presente se suscribe mediante firma facsimilar conforme lo previsto en el punto 7.9 del Reglamento General de la Actividad Aseguradora.</p>
<p><img src="membrete.jpg" width="1000" height="56" /></p>
</body>
</html>


EOD;

// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);

// ---------------------------------------------------------

// Close and output PDF document
// This method has several options, check the source code documentation for more information.
$pdf->Output('ejemplo_1.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
