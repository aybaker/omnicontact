<?php
	echo exec('pwd');
	echo "comandos para ver trafico en asterisk:<br>";
	echo "ver agentes online:<br>";
	echo exec('asterisk -rx "agent show online"');

	echo "muestra informacion de channels:<br>";
	echo exec('asterisk -rx "core show channels"');

	echo "List defined SIP peers:<br>";
	echo exec('asterisk -rx "sip show peers"');

?>