<?php

	define ( 'DB_IP', 'localhost' );
	define ( 'DB_USER', 'ftsender' );
	//define ( 'DB_PASS', 'ivujfakCiph9cyGhocfonn7' );
	define ( 'DB_PASS', 'Freetech123' );
	define ( 'IP', 'localhost' );
	define ( 'IP_CLIENTE', 'localhost' );
	define ( 'ID_PROYECTO', '1' );

?>