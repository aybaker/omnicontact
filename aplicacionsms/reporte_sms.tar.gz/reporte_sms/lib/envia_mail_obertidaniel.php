<html>
<head>
<title>POP before SMTP Test</title>
</head>
<body>

<?php
require_once('./PHPMailer_v5.1/class.phpmailer.php');
require_once('./PHPMailer_v5.1/class.pop3.php'); // required for POP before SMTP
require_once ('./PHPMailer_v5.1/class.smtp.php');



$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Host = "smtp.gmail.com";
$mail->Port = 465;
$mail->Username = "obertidaniel@gmail.com";
$mail->Password = "123456987";

/*
$pop = new POP3();
$pop->Authorise('pop.gmail.com', 995, 30, 'obertidaniel', '123456987', 1);

$mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
$mail->SMTPSecure = "ssl";
$mail->IsSMTP();
*/

try {
  $mail->SMTPDebug = 2;
  $mail->Host     = 'pop.gmail.com';
  $mail->AddReplyTo('doberti@desol.com.ar', 'Daniel O');
  $mail->AddAddress('doberti@desol.com.ar', 'Daniel O');
  $mail->SetFrom('doberti@desol.com.ar', 'Daniel Oberti');
////  $mail->AddReplyTo('name@yourdomain.com', 'First Last');
  $mail->Subject = 'asunto';
  $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automatically
////  $mail->MsgHTML(file_get_contents('contents.html'));
  $mail->MsgHTML("hola este es un mensaje");  
  ////$mail->AddAttachment('images/phpmailer.gif');      // attachment
  ////$mail->AddAttachment('images/phpmailer_mini.gif'); // attachment
  $mail->Send();
  echo "Message Sent OK</p>\n";
} catch (phpmailerException $e) {
  echo $e->errorMessage(); //Pretty error messages from PHPMailer
} catch (Exception $e) {
  echo $e->getMessage(); //Boring error messages from anything else!
}
?>

</body>
</html>
