<?php

/**
 *  by RolyNet
 *
 */


class IMAP{
 
  /**
   * Default POP3 port
   * @var int
   */
  var $IMAP_PORT = 143;

  /**
   * Default Timeout
   * @var int
   */
  var $IMAP_TIMEOUT = 30;

  /**
   * IMAP Carriage Return + Line Feed
   * @var string
   */
  var $CRLF = "\r\n";

  /**
   * Displaying Debug warnings? (0 = now, 1+ = yes)
   * @var int
   */
  var $do_debug = 2;

  /**
   * IMAP Mail Server
   * @var string
   */
  var $host;

  /**
   * IMAP Timeout Value
   * @var int
   */
  var $tval;

  /**
   * IMAP Username
   * @var string
   */
  var $user;

  /**
   * IMAP Password
   * @var string
   */
  var $pass;

  /**#@+
   * @access private
   */
  var $imap_cnx;
  var $connected;
  var $error;     //  Error log array
  /**#@-*/

  /**
   * Constructor, sets the initial values
   *
   * @return IMAP
   */
  function IMAP ()
    {
      $this->imap_conn = 0;
      $this->connected = false;
      $this->error = null;
    }

  /**
   * Combination of public events - connect, login, disconnect
   *
   * @param string $host e.g "{web.com:143/imap/notls}";
   * @param string $username e.g. email@web.com 
   * @param string $password is your mail
   */
  function openImap($host, $user, $pass)
  {
  	  if ($this->connected){
  	  	  closeImap();
  	  }
  	  	  $this->imap_cnx = imap_open($host,$user,$pass);
  	  	  if ($this->imap_cnx){
  	  	  	  $this->host = $host;
  	  	  	  $this->user = $user;
  	  	  	  $this->pass = $pass;
  	  	  	  $this->tval = $tval;
  	  	  	  $this->connected = true;
  	  	  	  return true;
  	  	  }
	return "<br />Error ".imap_last_error()." <br />";
 
  }
  /**
   *
   */
  function readMail($nromsg){
  	  if ($this->connected){
  	  	  $imap_header  = (array)(imap_headerinfo($this->imap_cnx, $nromsg));
  	  	  $imap_msg = imap_body($this->imap_cnx, $nromsg);
  	  	  $imap_body = split("\r\n", $imap_msg);
  	  	  $msg = array( 'massage'=>$imap_body ); 
  	  	  return (array_merge($imap_header, $msg ));
  	  }else{
  	  	  return "<br /> No Connected </br>";
  	  }
  }
  
  function getCountMsg(){
  	  if ($this->connected){
  	  	  return imap_num_msg($this->imap_cnx) ;
  	  }
  	  return -1;
  	  
  }
  function getUnreadMsg(){
  	  if ($this->connected){
  	  	  return imap_search ( $this->imap_cnx, "UNSEEN" );
  	  }
  	  return array();
  }
  
  function closeImap(){
  	  if ($this->connected){
  		  $sw = imap_close($this->imap_cnx);
  		  $this->connected = false; 		  
  	  }
  }
 
}


?>