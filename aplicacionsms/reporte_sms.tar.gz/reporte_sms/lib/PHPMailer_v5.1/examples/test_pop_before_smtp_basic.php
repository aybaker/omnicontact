<html>
<head>
<title>POP before SMTP Test</title>
</head>
<body>

<?php
require_once('../class.phpmailer.php');
require_once('../class.pop3.php'); // required for POP before SMTP

$pop = new POP3();
$pop->Authorise('pop3.compreseguros.com', 110, 30, 'carolina_2@compreseguros.com', 'Desol123', 1);

$pop->Connect ("pop3.compreseguros.com");
$pop->Login( "carolina_2@compreseguros.com", "Desol123" );
//$pop->sendString("user carolina_2@compreseguros.com\n\n");
echo $pop->getResponse;

echo "aqui env�o mail";

$mail = new PHPMailer();

$body             = file_get_contents('contents.html');
$body             = eregi_replace("[\]",'',$body);

$mail->IsSMTP();
$mail->SMTPDebug = 2;
$mail->Host     = 'smtp.compreseguros.com';

$mail->SetFrom('carolina_2@compreseguros.com', 'Caro');

$mail->AddReplyTo("doberti@desol.com.ar","D.O.");

$mail->Subject    = "asunto";

$mail->AltBody    = "mensaje alternativo"; // optional, comment out and test

$mail->MsgHTML($body);

$address = "obertidaniel@gmail.com";
$mail->AddAddress($address, "D.O.");

$mail->AddAttachment("images/phpmailer.gif");      // attachment
$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment


if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}

?>

</body>
</html>
