<?php


# yum -y install php-pgsql

class DataBase {

	public static $db_ip;
	public static $db_user;
	public static $db_pass;
	public static $db_base;
	
	private $conexion;
	private $resource;
	private $sql;
	public static $queries;
	private static $_singleton;

	private function set_constantes()
	{
		$this->db_ip = DB_IP;
		$this->db_user = DB_USER;
		$this->db_pass = DB_PASS;
		$this->db_base = 'ftsender';		
	}
	
	public static function getInstance(){
		if (is_null (self::$_singleton)) {
			self::$_singleton = new DataBase();
		}		
		return self::$_singleton;
	}

	private function __construct(){
		$this->set_constantes();
		$this->conexion = pg_connect( "host=".$this->db_ip." port=5432 dbname=".$this->db_base." user=".$this->db_user." password=".$this->db_pass."" );
		####mysql_select_db( $this->db_base, $this->conexion );
		$this->queries = 0;
		$this->resource = null;
	}

	//devuelve el result de la consulta
	public function execute()
	{
		if(!($this->resource = pg_query($this->conexion, $this->sql))){
			echo "<b style='position:absolute;z-index:999999;' >ERROR: ".pg_last_error()."</b>";
			return null;
		}
		$this->queries++;
		return $this->resource;
	}
	
	public function set_and_execute( $sql )
	{
		$this->setQuery($sql);
		return $this->execute();
	}	
	
	public function setQuery($sql){
		if(empty($sql)){
			return false;
		}
		$this->sql = $sql;
		return true;
	}
	
	//retorna la cantidad de registros si la consulta no hubiese usado limit
	public function get_found_rows()
	{
		$aux = explode("LIMIT", $this->sql);
		$sql_sin_limit = $aux[0];
		$result_sin_limit = pg_query( $this->conexion, $sql_sin_limit )or die( pg_last_error() ); 
		$rowTotal = pg_num_rows( $result_sin_limit );
		return $rowTotal;
	}
	
	public function get_totalCol()
	{
		return pg_num_fields($this->resource);
	}
	
	public function get_totalFil()
	{
		return pg_numrows($this->resource);
	}	
	
	public function alter(){
		if(!($this->resource = pg_query($this->conexion, $this->sql))){
			return false;
		}
		return true;
	}

	//retorna un array con todos los nombres de las columnas
	public function load_nombres_col()
	{
		$array = array();
		for($i=0; $i<pg_num_fields($this->resource); $i++)
		{
			$name = pg_field_name($this->resource,$i);
			$array[] = $name;
		}
		return $array;
	}
	
	public function load_resource($tipo)
	{
		if (!($cur = $this->execute())) { return null; }
		$array = array();
		switch( $tipo )
		{
			case 'object':		while ($row = pg_fetch_object($cur))	{ $array[] = $row; } break;
			case 'array':		while ($row = pg_fetch_array($cur))	{ $array[] = $row; } break;
			case 'assoc':		while ($row = pg_fetch_assoc($cur))	{ $array[] = $row; } break;
			default: return null;
		}
		return $array;
	}

	public function freeResults(){
		pg_freeResult($this->resource);
		return true;
	}

	public function loadObject()
	{
		if ($cur = $this->execute())
		{
			if ($object = pg_fetch_object($cur))
			{
				pg_freeResult($this->resource);
				return $object;
			}
			else { return null; }
		}
		else { return false; }
	}

	function __destruct(){
		pg_freeResult($this->resource);
		pg_close($this->conexion);
	}
}

?>
