#!/bin/bash

asterisk -rx 'agent show online'