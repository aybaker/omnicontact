#!/usr/bin/python
# -*- coding: utf8 -*-

from settings import *

import commands
import os,sys

import logging
import logging.handlers

pathname, scriptname = os.path.split(sys.argv[0])
RUTA = os.path.abspath(pathname)+"/"
#RUTA = os.getcwd()+"/"

def separador(titulo="---"):
	print
	print "______________________________________ "+ titulo +" ______________________________________________"
	print

def crearsinoexiste(archivo):
	commands.getoutput("ls -lh "+archivo+" | touch "+archivo+"")

class ColorFormatter(logging.Formatter):
	def color(self, level=None):
		codes = {\
			None:       (0,   0),
			'DEBUG':    (0,   2), 
			'INFO':     (0,   0), 
			'WARNING':  (1,  34),
			'ERROR':    (1,  31), 
			'CRITICAL': (1, 101), 
			}
		return (chr(27)+'[%d;%dm') % codes[level]

	def format(self, record):
		retval = logging.Formatter.format(self, record)
		return self.color(record.levelname) + retval + self.color()

def crearLog(nombre):
	logger=logging.getLogger(nombre)
	logger.setLevel(logging.DEBUG)
	handler = logging.handlers.TimedRotatingFileHandler(filename=nombre+'.log', when="m", interval=1, backupCount=5) 
	handler.setFormatter(ColorFormatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%y-%m-%d %H:%M:%S'))
	logger.addHandler(handler)
	return logger

