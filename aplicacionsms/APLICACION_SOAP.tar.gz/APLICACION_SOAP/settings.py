#!/usr/bin/python
# -*- coding: utf8 -*-

#/* CLIENTE: Indica el nombre del cliente */
CLIENTE = 'Cliente-1'
IP = '127.0.0.1'
PORT = 1117

#> DATOS PARA CONECTARSE A LA BASE DE DATOS DE DJANGO
DB_HOST_PSQL = '127.0.0.1'
DB_PORT_PSQL = '5432'
DB_USER_PSQL = 'ftsender'
DB_PASS_PSQL = 'Freetech123'
DB_BASE_PSQL = 'ftsender'

#/* Indica si esta habilitada la contactacion por email ante errores (0:NO/1:SI) */
FLAG_CONTACTAR_EMAIL_ERROR = 1

#/* EMAIL DE CONTACTO */
CONTACTAR_EMAIL = 'federicopeker@gmail.com'

#/* HORARIO DE SERVICIO */
HR_INICIO = -1
HR_FIN = 25

### LOS SIGUIENTES PARAMETROS NO DEBEN SER MODIFICADOS ###
NOMBRE_DEMONIO = 'soap'

