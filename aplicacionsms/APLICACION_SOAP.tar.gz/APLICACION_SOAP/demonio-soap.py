#!/usr/bin/python
# -*- coding: utf8 -*-

import settings
from settings import *
import librerias
from librerias import *

import os
import time
os.environ['PYTHON_EGG_CACHE'] = '/tmp/'

from soaplib.wsgi_soap import SimpleWSGISoapApp
from soaplib.service import soapmethod
from soaplib.serializers.primitive import String, Integer, Array, Boolean
from soaplib.serializers.binary import Attachment
import commands

import random
import string

import multiprocessing as mp

import sys

import psycopg2

logger1 = crearLog('/var/log/demonio-'+NOMBRE_DEMONIO+'_ws')
logger2 = crearLog('/var/log/demonio-'+NOMBRE_DEMONIO+'_process')
	
	
class SOAPService(SimpleWSGISoapApp):
	
	@soapmethod(String,String,String,String,String,_returns=String)
	def carga(self,user,password,datos,metadata,tipo):
		prefijo = " <<WS:carga>> "
		
		hora = int(  time.strftime("%H")  )
		if hora<=HR_INICIO or hora>=HR_FIN:
			resp = "ERROR: Fuera del horario de atencion"
			logger1.warning( prefijo+"resp:"+resp )
			return resp
		
		logger1.debug( "=======================================" )
		logger1.info( prefijo+"...procesando consulta de carga" )
		user = str(user)
		password = str(password)
		aux_datos = str(datos)
		metadata = str(metadata)
		tipo = str(tipo)
		
		logger1.info( prefijo+"RUTA:"+RUTA )
		comando = "fgrep -r ';;%s;;%s;;' %susuarios.txt | wc -l" % (user,password,RUTA)
		logger1.info( prefijo+comando )
		flag_loguin = int(commands.getoutput(comando))
		logger1.info( prefijo+"flag_loguin:"+str(flag_loguin) )
		if flag_loguin == 0:
			resp = "ERROR: fallo de autenticacion"
			return resp
		
		logger1.debug( prefijo )
		logger1.debug( prefijo+"	user:"+user+"\n" )
		logger1.debug( prefijo+"	password:"+password+"\n" )
		logger1.debug( prefijo+"	datos:"+aux_datos+"\n" )
		logger1.debug( prefijo+"	metadatos:"+metadata+"\n" )
		logger1.debug( prefijo+"	tipo:"+tipo+"\n" )
		logger1.debug( prefijo )
		
		cant_caracteres_datos = len(aux_datos)
		if cant_caracteres_datos > 600000:
			resp = "ERROR: Ha sobrepasado el limite (500.000) de caracteres permitidos para el campo 'datos', - Ud. tiene "+str(cant_caracteres_datos)+" caracteres."
			return resp
		
		try:
			lista_datos = eval( datos )
		except Exception as e:
			mensaje = 'ERROR al procesar los datos: '+str(e)
			logger1.critical( prefijo+mensaje )
			resp = "ERROR: la estructura datos presenta errores, por favor reviselo"
			return resp
		

		
		cant = 60000
		n_division = cant
		aux_datos1 = aux_datos[:(n_division+cant)]
		n_division = n_division + cant
		aux_datos2 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos3 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos4 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos5 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos6 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos7 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos8 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos9 = aux_datos[n_division:(n_division+cant)]
		n_division = n_division + cant
		aux_datos10 = aux_datos[n_division:]

		logger1.debug( prefijo+aux_datos1+aux_datos2+aux_datos3+aux_datos4+aux_datos5+aux_datos6+aux_datos7+aux_datos8+aux_datos9+aux_datos10 )
		
		try:
			lista_metadata = eval( metadata )
			cant_columnas = str(len(lista_metadata))
		except Exception as e:
			mensaje = 'ERROR al procesar los metadatos: '+str(e)
			logger1.critical( prefijo+mensaje )
			resp = "ERROR: la estructura metadatos presenta errores, por favor reviselo"
			return resp
		
		logger1.critical( prefijo+"metadata:"+metadata )
		metadata = metadata.replace('""', '"COLUMNA_1"')
		lista_metadata[0] = "COLUMNA_1"
		metadata = str(lista_metadata).upper()
		metadata = metadata.replace("'", '"')
		logger1.critical( prefijo+"metadata:"+metadata )
		
		
		logger1.debug( prefijo+"cant_columnas:"+cant_columnas )
		
		
		metadatos = '{"col_telefono": 0, "cols_fecha": [], "prim_fila_enc": true, "nombres_de_columnas": '+metadata+', "cols_hora": [5], "cant_col": '+cant_columnas+'}'
		#lista_metadata = eval( metadata )
		
		N=6
		token = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(20))	
		logger1.info( prefijo+"token generado:"+token )
		
		try:
			psql_connection = psycopg2.connect(database=DB_BASE_PSQL, user=DB_USER_PSQL, password=DB_PASS_PSQL, host=DB_HOST_PSQL, port=DB_PORT_PSQL)
			psql_cursor = psql_connection.cursor()
			psql_cursor.execute('''INSERT INTO consultas_sms (token, metadatos, estado, userfield, password, datos1, datos2, datos3, datos4, datos5, datos6, datos7, datos8, datos9, datos10 ) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);''', (token, metadatos, 'Procesando', user, password, aux_datos1, aux_datos2, aux_datos3, aux_datos4, aux_datos5, aux_datos6, aux_datos7, aux_datos8, aux_datos9, aux_datos10))
			psql_connection.commit()
			psql_connection.close()
		except Exception as e:
			mensaje = 'ERROR al procesar los datos: '+str(e)
			logger1.critical( prefijo+mensaje )
			token = mensaje
		
		resp = token
		logger1.info( prefijo+"resp:"+resp )
		return resp
		
	@soapmethod(String,String,String,_returns=String)
	def estado(self,user,password,token):
		prefijo = " <<WS:estado>> "
		
		hora = int(  time.strftime("%H")  )
		if hora<=HR_INICIO or hora>=HR_FIN:
			resp = "ERROR: Fuera del horario de atencion"
			logger1.warning( prefijo+"resp:"+resp )
			return resp
			
		user = str(user)
		password = str(password)
		
		logger1.info( prefijo+"RUTA:"+RUTA )
		comando = "fgrep -r ';;%s;;%s;;' %susuarios.txt | wc -l" % (user,password,RUTA)
		logger1.info( prefijo+comando )
		flag_loguin = int(commands.getoutput(comando))
		logger1.info( prefijo+"flag_loguin:"+str(flag_loguin) )
		if flag_loguin == 0:
			resp = "ERROR: fallo de autenticacion"
			return resp
		
		
		estado = "ERROR"
		logger1.debug( "=======================================" )
		logger1.info(prefijo+"...procesando consulta de estado")
		try:
			flag_existe_token = False
			psql_connection = psycopg2.connect(database=DB_BASE_PSQL, user=DB_USER_PSQL, password=DB_PASS_PSQL, host=DB_HOST_PSQL, port=DB_PORT_PSQL)
			psql_cursor = psql_connection.cursor()
			psql_cursor.execute(''' SELECT estado FROM consultas_sms WHERE token=%s ; ''', (token))
			resultados = psql_cursor.fetchall()
			for row in resultados:
				flag_existe_token = True
				estado = row[0]
				logger1.info( prefijo+"estado:"+estado )
			psql_connection.close()
			
			if flag_existe_token == False:
				estado = "Inexistente"
			
			logger1.info(prefijo+"fin de procesamiento OK")
		except Exception as e:
			estado = 'ERROR al procesar los datos: '+str(e)
			logger1.critical(prefijo+estado)
		logger1.info(prefijo+"estado:"+estado)
		resp = token+';'+estado
		logger1.info(prefijo+"resp:"+resp)
		return resp

	def ejecutar(self):
		output = mp.Queue()
		processes = [mp.Process(target=self.proceso_trabajar, args=(1,output)),    mp.Process(target=self.servidor_web, args=(2,output))]
		for p in processes:
			p.start()
		results = [output.get() for p in processes]
		print(results) 
		
	def servidor_web(self, numero, output):
		logger1.info( "proceso "+str(numero) )
		from wsgiref.simple_server import make_server
		application=SOAPService()
		server = make_server(IP, PORT, application)
		logger1.info( "iniciando..." )
		server.serve_forever()

		
	def proceso_trabajar(self, numero, output):
		prefijo = " <<PROCESANDO>> "
		logger2.debug( "proceso "+ str(numero) )
		
		output = 0
		while 1:
			output = output + 1
			estado_nuevo = "ERROR"
			time.sleep(1)
			try:
				
				psql_connection = psycopg2.connect(database=DB_BASE_PSQL, user=DB_USER_PSQL, password=DB_PASS_PSQL, host=DB_HOST_PSQL, port=DB_PORT_PSQL)
				psql_cursor = psql_connection.cursor()
				psql_cursor.execute(''' SELECT fecha, token, metadatos, estado, userfield, password, datos1, datos2, datos3, datos4, datos5, datos6, datos7, datos8, datos9, datos10 FROM consultas_sms
							WHERE estado='Procesando' AND fecha BETWEEN  CURRENT_TIMESTAMP - INTERVAL '15 MINUTE'  and CURRENT_TIMESTAMP limit 1; ''')
				resultados = psql_cursor.fetchall()
				for row in resultados:
					logger2.warning( prefijo+"...procesando" )
					aux_fecha = str(row[0])
					aux_token = str(row[1])					
					aux_metadatos = str(row[2])
					aux_estado = str(row[3])
					aux_user = str(row[4])
					aux_password = str(row[5])
					
					aux_datos1 = str(row[6])
					aux_datos2 = str(row[7])
					aux_datos3 = str(row[8])
					aux_datos4 = str(row[9])
					aux_datos5 = str(row[10])
					aux_datos6 = str(row[11])
					aux_datos7 = str(row[12])
					aux_datos8 = str(row[13])
					aux_datos9 = str(row[14])
					aux_datos10 = str(row[15])
					aux_datos = aux_datos1+aux_datos2+aux_datos3+aux_datos4+aux_datos5+aux_datos6+aux_datos7+aux_datos8+aux_datos9+aux_datos10
					
					lista_datos = eval( aux_datos )
					aux_cantidad_contactos = str(len(lista_datos))
					
					
					logger2.debug( prefijo+"aux_fecha:"+aux_fecha )
					logger2.debug( prefijo+"aux_token:"+aux_token )
					logger2.debug( prefijo+"aux_datos:"+aux_datos )
					logger2.debug( prefijo+"aux_metadatos:"+aux_metadatos )
					logger2.debug( prefijo+"aux_estado:"+aux_estado )
					logger2.debug( prefijo+"aux_user:"+aux_user )
					logger2.debug( prefijo+"aux_password:"+aux_password )
					
					aux_nombre = "WS_basecontacto_" + str( time.strftime('%Y%m%d_%H:%M:%S') )
					
					logger2.debug( prefijo+"genero base de datos de contacto nueva" )

					psql_cursor.execute(''' INSERT INTO fts_web_basedatoscontacto (fecha_alta,nombre,archivo_importacion,nombre_archivo_importacion,sin_definir,cantidad_contactos,estado,metadata) VALUES (CURRENT_TIMESTAMP,%s, '-', '-', 'f', %s, 1, %s); ''', (aux_nombre, aux_cantidad_contactos, aux_metadatos))
					
					logger2.debug( prefijo+"busco el id del nuevo registro creado en la tabla fts_web_basedatoscontact" )
					aux_id_basedatoscontacto = "-"
					sql = "select id from fts_web_basedatoscontacto where nombre='%s';" % (aux_nombre)
					psql_cursor.execute(sql)
					logger2.debug( prefijo+"buscando..." )
					resultados = psql_cursor.fetchall()
					for row in resultados:
						aux_id_basedatoscontacto = str(row[0])
						logger2.debug( prefijo+"el id de la nueva base de contactos es: "+aux_id_basedatoscontacto )
					
					logger2.debug( prefijo+"guardo cada tupla de datos del contacto" )
					if aux_id_basedatoscontacto != "-":
						for dato in lista_datos:
							dato_str = str(dato)
							psql_cursor.execute(''' INSERT INTO fts_web_contacto (datos, bd_contacto_id) 
												VALUES (%s, %s); ''',(dato_str, aux_id_basedatoscontacto))
							estado_nuevo = "OK"
					else:
						logger2.critical( prefijo+"ERROR con el valor de aux_id="+aux_id_basedatoscontacto )
					
					psql_cursor.execute('''UPDATE consultas_sms SET estado=%s WHERE token=%s;''', (estado_nuevo, aux_token))
					psql_connection.commit()
					
					psql_connection.close()
				
			except Exception as e:
				estado = 'ERROR al procesar los datos: '+str(e)
				logger2.critical( prefijo+estado )


def start():
	print "<<<<Inicia>>>>"
	os.chdir(os.path.dirname(RUTA[:-1]))
	servicio = SOAPService()
	servicio.ejecutar()

start()
