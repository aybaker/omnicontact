#!/usr/bin/python
# -*- coding: utf8 -*-

from settings import *
from librerias import *

import socket
import string
import commands
import time
from time import gmtime, strftime
import os
import datetime

DESTINATARIOS = CONTACTAR_EMAIL

CANTIDAD_OK_PROCESOS = 3

lista_servicios = [('python', RUTA, 'demonio-'+NOMBRE_DEMONIO+'.py', '/var/log/demonio-'+NOMBRE_DEMONIO+'.log')]
SLEEP = 10

class Supervisor:

    def __init__(self):
		self.conectado = 0

    def Controlar(self):	
		
		for servicio in lista_servicios:
			ejecutar = "ps axu | grep "+servicio[2]+" | grep -v grep -wc"
			resultado = int(commands.getoutput(ejecutar))
			
			if resultado == 0:
				print "levanto "+servicio[2]+""
				comando = "nohup "+servicio[0]+" "+servicio[1]+""+servicio[2]+" &"
				print comando
				os.system(comando)
				os.system("tail -n10 "+servicio[3]+" | mailx -s 'Servicio "+servicio[2]+" detenido - "+CLIENTE+"' "+DESTINATARIOS+"")
			elif resultado == CANTIDAD_OK_PROCESOS:
				print "todo bien"
			elif resultado != CANTIDAD_OK_PROCESOS:
				print "ALERTA: La cantidad de procesos es incorrecta!"
				os.system("ps axu | grep "+servicio[2]+" | grep -v grep   |   mailx -s 'Servicio "+servicio[2]+" duplicado - "+CLIENTE+"' "+DESTINATARIOS+"")
				
				for i in range (0, resultado):
					print "("+ str(i) +") Se procede con la eliminacion de procesos para iniciarlos nuevamente..."
					comando = "ID_proceso=$(ps axu | grep demonio-"+NOMBRE_DEMONIO+".py | grep -v grep -m 1 | awk '{print $2}');kill $ID_proceso"
					print comando
					id_proceso = os.system(comando)
			
		
    def Ejecutar(self):
		print "\n\n\n\ninicia supervisor\n\n\n\n"
		#os.chdir("/root/")
		while 1:
			hora = int(  time.strftime("%H")  )
			print str(hora)
			if hora>=HR_INICIO and hora<=HR_FIN:
				print "control"
				self.Controlar()
			time.sleep(SLEEP)

def start():
	os.chdir(os.path.dirname(RUTA[:-1]))
	sup = Supervisor()
	sup.Ejecutar()

start()

